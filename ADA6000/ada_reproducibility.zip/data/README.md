# Intermediate data dictionary

All times in the CSV files are milliseconds. `*_native` errors use the original model output units. CSV files retain the available numerical precision; display rounding belongs in the report. No new GPU benchmark was run to generate these exports.

| File | Rows / structure | Meaning |
|---|---|---|
| `tiers.csv` | 12 configurations | BF16 reference plus T0–T10. BF16 candidate coverage is blank because it is not a tier of the W8A8-to-W4A4 schedule. Plan latency is pooled across 90 repeated calls per configuration. GPU operation sums come from a separate six-plan profile. |
| `rounds.csv` | 36 configuration/round rows | Three randomized rounds, order position, and per-round median of 30 plan calls. Round numbers are one-based. |
| `latency_samples.csv` | 1,080 plan rows | Lossless seconds-to-ms conversion of the original 180 replay records × six plan calls. Replay/round indices are one-based; plan indices are zero-based. `cuda_event_stream_span_ms` includes submission gaps and is not the sum of GPU operation durations. |
| `graph_breakdown.csv` | category rows for five modes | Separate-profile mean GPU operation sums restricted to the DiT Graph for BF16/T0/T7/T8/T9. `TOTAL` must not be added again to the component rows. |
| `graph_counts.csv` | category rows for five modes | Corresponding mean GPU event counts per DiT Graph. The original diagnostic field is named `graph_kernel_count`; the categories also distinguish copy/layout work. |
| `t7_t8_delta.csv` | two scopes × categories | T8 minus T7 category durations, separately for whole plan and DiT Graph. These are separate-profile differences, not decompositions of unprofiled host medians. |
| `latency_causes.json` | five modes | Detailed trace means, category sums, kernel-name counts and six per-plan diagnostic records. Trace hashes identify the original compressed traces, which are not bundled here. |
| `selected_sites.json` | eleven tiers | Exact candidate-site bit mapping; fixed selected noncandidate Linear bits, category projections, and active same-input projection groups by bit width. Coverage counts Linear sites, not parameters/FLOPs. |
| `provenance.json` | structured metadata | Measured base plus patch, later inspected upstream revision, hardware/runtime, checkpoint hashes, external backend evidence, original file hashes, measurement protocol and limitations. |
| `validation_summary.json` | structured results | Numerical checks and tests with exact scope, including the existing GPU-test failures and the single BF16 pristine-base reproduction. |
| `sanitization.json` | per-file ledger | Original/distributed hashes and sanitization changes. No source evidence was modified. |

The action-error metrics compare only the six plan-action arrays to matched full BF16 and exclude bootstrap. Since all quantized tiers keep selected VLM Linear modules at W8A8, these errors include effects from VLM quantization. They are fixed-replay diagnostics, not closed-loop task-quality measurements.

The 90 samples per configuration repeatedly use one fixed episode segment. The p10/p90 columns are empirical quantiles, not confidence intervals. The separate profiler replay has only six plan observations per configuration. In particular, the GPU sum cannot be subtracted from host median to infer CPU time.

Original traces, raw captured tensors and full validation structures remain in the original evidence archive and are identified by hashes where applicable; they are not included in this compact Overleaf attachment. No host IP, login name, absolute private path, GPU UUID, input images, checkpoint tensors or credential is embedded in these exported datasets.
