"""Matched 11-tier checkpoint-500 replay; raw samples, errors and separate traces."""
import argparse
import gc
import gzip
import hashlib
import json
import random
import time
from collections import Counter, defaultdict
from dataclasses import replace
from pathlib import Path

import numpy as np
import torch
import replay_spatial_checkpoint as replay
from replay_profile_report import attribution
from coexecution.libero.backend import Backend
from coexecution.libero.service import load_core
from scripts.libero_experiment_utils import checkpoint_identity
from coexecution.optimization.config import OptimizationConfig
from coexecution.optimization.session import GrootOptimizations


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def summarize(values):
    return {"n": len(values), "median": float(np.median(values)),
            "p10": float(np.percentile(values, 10)), "p90": float(np.percentile(values, 90)),
            "p95": float(np.percentile(values, 95)), "min": min(values), "max": max(values)}


def profile(path, tier):
    events = json.loads(path.read_text())["traceEvents"]
    mapped, counts = attribution(events)
    totals, names = Counter(), defaultdict(Counter)
    for event, phase in mapped:
        totals[phase] += event["dur"] / 1000
        names[phase][event["name"]] += event["dur"] / 1000
    assert totals["unassigned"] == 0, totals
    assert counts == {"bootstrap": 1, "vision": 6, "plan": 6}
    kernels = [e for e in events if e.get("ph") == "X" and e.get("cat") == "kernel"]
    integer = {}
    for bits, element, tile in [(8, "signedchar", "GemmShape<16,8,32>"),
                                (4, "integer_subbyte<4,true>", "GemmShape<16,8,64>")]:
        matched = [e for e in kernels if element in e["name"].replace(" ", "")
                   and tile in e["name"].replace(" ", "")]
        integer[str(bits)] = len(matched)
        assert bool(matched) == (tier is not None and (bits == 8 or tier > 0)), integer
    return {"phase_mean_gpu_sum_ms": {k: totals[k]/counts[k] for k in counts},
            "phase_total_gpu_sum_ms": dict(totals),
            "phase_kernel_sums_ms": {k: dict(v) for k, v in names.items()},
            "integer_kernel_counts": integer}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", type=Path, required=True)
    p.add_argument("--dataset", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--shape-tactics", type=Path, required=True)
    p.add_argument("--rounds", type=int, default=3)
    p.add_argument("--samples", type=int, default=5)
    a = p.parse_args()
    assert a.rounds >= 3 and a.samples >= 5
    a.output.mkdir(parents=True, exist_ok=False)
    assert torch.cuda.device_count() == 1
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    core = load_core(a.checkpoint, a.output, "cuda:0")
    assert core.model.config.streaming and core.model.config.action_horizon == 40
    initial, plans, episode = replay.observations_and_prefixes(core, a.dataset, 0, 20, 6, "torchcodec")
    backend = Backend(core, "pir2", a.output)
    category = int(core._collate_state_only({"state": initial["state"]})[0]["embodiment_id"].item())
    base = OptimizationConfig(fusion=True, dit_graph=True, scope="all", vision_channels_last=True)
    modes = {"bf16": base, **{f"t{t}": replace(base, precision="w8a8", quant_tier=t,
              category_id=category, norm_modulation_quant=True, residual_norm_quant=True,
              shape_tactics=a.shape_tactics) for t in range(11)}}
    rng = random.Random(1729)
    orders = []
    for _ in range(a.rounds):
        order = list(modes)
        rng.shuffle(order)
        orders.append(order)
    manifest = {"status": "started", "checkpoint": checkpoint_identity(a.checkpoint),
        "gpu": str(torch.cuda.get_device_properties(0)), "gpu_uuid": str(torch.cuda.get_device_properties(0).uuid),
        "torch": torch.__version__, "cuda": torch.version.cuda, "attention": replay.attention_runtime(core),
        "episode": episode, "start": 20, "seed": 1000, "calls": 6,
        "rounds": a.rounds, "samples_per_round": a.samples, "warmup_replays_per_selection": 3,
        "orders": orders, "category": category, "baseline": "Matched fused full BF16",
        "scope": "Synchronized local streaming plan call including existing backend bookkeeping; excludes RPC, simulator, scheduling and separate VLM update",
        "protocol": "GR00T32 adaptation of Cosmos role order; early B0-9, mid B10-19, late B20-31; 192 attention/FFN candidate Linear sites",
        "fixed_precision": "VLM, norm/condition, noncandidate action projections and category projections W8A8 at all tiers; attention core remains floating",
        "exclusions": "Installation, weight packing, compilation, graph capture and three warmup replays; traces separately collected outside latency samples",
        "quality": "Fixed-demonstration action errors only; not closed-loop success",
        "source_sha256": {str(f.relative_to(replay.ROOT)): hashlib.sha256(f.read_bytes()).hexdigest()
             for f in (list((replay.ROOT/'coexecution').rglob('*.py')) + list(Path(__file__).parent.glob('*.py')))},
        "shape_tactics_sha256": hashlib.sha256(a.shape_tactics.read_bytes()).hexdigest()}
    write(a.output/'manifest.json', manifest)
    raw, validations, profile_rows = [], {}, {}

    def run(evidence=False):
        return replay.replay(backend, initial, plans, 1000, evidence=evidence)

    with torch.inference_mode(), torch.cuda.stream(backend.stream):
        with GrootOptimizations(core, base):
            run()
            golden, _, _ = run(True)
        np.savez(a.output/'bf16-reference.npz', **golden)
        for round_index, order in enumerate(orders):
            for mode in order:
                config = modes[mode]
                output = a.output/mode
                output.mkdir(exist_ok=True)
                backend.output = output
                started = time.perf_counter()
                with GrootOptimizations(core, config) as scope:
                    for _ in range(3):
                        run()
                    actual, _, audit = run(True)
                    errors = replay.differences(actual, golden)
                    assert all(v['finite'] for v in errors.values())
                    assert all(v['exact'] for k, v in errors.items() if k.startswith('times_') or k == 'cuda_rng_state')
                    if mode == 'bf16':
                        assert all(v['exact'] for v in errors.values())
                    if mode in validations:
                        prior = dict(np.load(output/'outputs.npz'))
                        assert all(v['exact'] for v in replay.differences(actual, prior).values())
                    else:
                        np.savez(output/'outputs.npz', **actual)
                    action_errors = np.concatenate([(actual[k].astype('float64')-golden[k]).ravel()
                                                   for k in actual if k.startswith('actions_') and k != 'actions_bootstrap'])
                    validations[mode] = {"vs_bf16": errors, "plan_action_mae": float(np.abs(action_errors).mean()),
                        "plan_action_rmse": float(np.sqrt((action_errors**2).mean())),
                        "plan_action_max_abs": float(np.abs(action_errors).max()), "audit": audit,
                        "evidence": scope.evidence()}
                    write(a.output/'validation.json', validations)
                    for sample in range(a.samples):
                        _, timings, _ = run()
                        row = {"mode": mode, "round": round_index, "sample": sample, "calls": timings}
                        raw.append(row)
                        with (a.output/'samples.jsonl').open('a') as f:
                            f.write(json.dumps(row)+'\n')
                    if round_index == a.rounds - 1:
                        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                                                torch.profiler.ProfilerActivity.CUDA]) as trace:
                            run()
                        path = output/'trace.json'
                        trace.export_chrome_trace(str(path))
                        profile_rows[mode] = profile(path, config.quant_tier)
                        profile_rows[mode]['source_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
                        with gzip.open(str(path)+'.gz', 'wb') as f:
                            f.write(path.read_bytes())
                        path.unlink()
                        write(a.output/'profiles.json', profile_rows)
                backend.reset({"seed": 1000})
                gc.collect()
                torch.cuda.empty_cache()
                subset = [c['host_wall_seconds']*1000 for r in raw if r['mode'] == mode
                          for c in r['calls'] if c['kind'] == 'plan']
                print('MEASURED', round_index, mode, summarize(subset), 'seconds', time.perf_counter()-started, flush=True)
        backend.output = a.output
        with GrootOptimizations(core, base):
            restored, _, _ = run(True)
        assert all(v['exact'] for v in replay.differences(restored, golden).values())
    summary = {}
    for mode, config in modes.items():
        phase = {}
        for kind in ('bootstrap', 'vision', 'plan'):
            calls = [c for r in raw if r['mode'] == mode for c in r['calls'] if c['kind'] == kind]
            phase[kind] = {metric: summarize([c[metric]*1000 for c in calls])
                          for metric in ('host_wall_seconds', 'gpu_stream_span_seconds')}
        count = validations[mode]['evidence']['coverage'].get('w4_candidate_count', 0)
        summary[mode] = {'tier': config.quant_tier, 'w4_count': count, 'candidate_count': 192,
            'w4_fraction': count/192, 'latency_ms': phase,
            'round_plan_medians_ms': [float(np.median([c['host_wall_seconds']*1000 for r in raw
               if r['mode'] == mode and r['round'] == i for c in r['calls'] if c['kind'] == 'plan']))
               for i in range(a.rounds)],
            'action_mae': validations[mode]['plan_action_mae'],
            'action_rmse': validations[mode]['plan_action_rmse'],
            'action_max_abs': validations[mode]['plan_action_max_abs'],
            'profile': profile_rows[mode]}
    write(a.output/'summary.json', summary)
    manifest.update(status='complete', restored_bf16_exact=True)
    write(a.output/'manifest.json', manifest)
    print('PROGRESSIVE_REPLAY_COMPLETE', flush=True)


if __name__ == '__main__':
    main()
