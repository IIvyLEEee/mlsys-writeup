"""Local matched piR2 replay. Real demonstrations are inputs, not a closed loop.

Run from a prepared CUDA environment after checkpoint-500 is complete. Model
loading, adapter construction, warm-up, evidence copies and trace recording are
excluded from the reported unprofiled host-call timings. No RPC or simulator is
timed; the existing Backend still accounts for its own request-log writes.
"""

import argparse
import hashlib
import json
import math
import random
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "scripts")]


def observations_and_prefixes(core, dataset, episode, start, calls, video_backend):
    import numpy as np
    from gr00t.data.dataset.lerobot_episode_loader import LeRobotEpisodeLoader
    from libero_inference_backend import KEYS
    from libero_protocol_scheduler import project_commands

    random.seed(1000)
    loader = LeRobotEpisodeLoader(
        dataset, core.modality_configs, video_backend=video_backend
    )
    data = loader[episode]

    def observation(index):
        row = data.iloc[index]
        output = {}
        for modality in ("video", "state", "language"):
            output[modality] = {}
            for key in core.modality_configs[modality].modality_keys:
                value = row[f"{modality}.{key}"]
                output[modality][key] = (
                    [[str(value)]]
                    if modality == "language"
                    else np.asarray(
                        value, dtype=np.uint8 if modality == "video" else np.float32
                    )[None, None]
                )
        return output

    tick = 0
    plans = []
    for index in range(calls):
        delay = (1, 3, 5)[index % 3]
        age = (0, 2, 5)[index % 3]
        assert start + tick - age >= 0
        assert start + tick + delay <= len(data)
        actions = np.stack(
            [
                np.concatenate(
                    [np.asarray(data.iloc[i][f"action.{key}"]) for key in KEYS]
                )
                for i in range(start + tick, start + tick + delay)
            ]
        ).astype(np.float32)
        plans.append(
            {
                "tick": tick,
                "delay": delay,
                "age": age,
                "observation": observation(start + tick),
                "visual": observation(start + tick - age),
                "committed": project_commands(actions),
            }
        )
        tick += delay
    return (
        observation(start),
        plans,
        {**loader.episodes_metadata[episode], "dataset_fps": loader.fps},
    )


def replay(backend, initial, plans, seed, evidence=True):
    import numpy as np
    import torch

    arrays, timings, audits = {}, [], []

    def timed(kind, index, function, **kwargs):
        backend.stream.synchronize()
        begin, end = (torch.cuda.Event(enable_timing=True) for _ in range(2))
        started = time.perf_counter()
        # Backend methods assume their caller selects the worker's private stream.
        # Both events and model calls must use that stream, not the default stream.
        with torch.cuda.stream(backend.stream):
            begin.record(backend.stream)
            with torch.profiler.record_function(f"replay::{kind}"):
                result = function(**kwargs)
            end.record(backend.stream)
        backend.stream.synchronize()
        host_wall = time.perf_counter() - started
        timings.append(
            {
                "kind": kind,
                "index": index,
                "host_wall_seconds": host_wall,
                "gpu_stream_span_seconds": begin.elapsed_time(end) / 1000.0,
            }
        )
        return result

    def save(index, raw):
        if not evidence:
            return
        head = backend.core.model.action_head
        arrays[f"actions_{index}"] = np.asarray(raw).copy()
        arrays[f"buffer_{index}"] = head._stream_buf.float().cpu().numpy().copy()
        arrays[f"times_{index}"] = head._stream_buf_t.float().cpu().numpy().copy()

    # bootstrap calls the actual Backend.reset and clears both policy caches.
    boot = timed(
        "bootstrap",
        -1,
        backend.bootstrap,
        observation=initial,
        capture_s=1000.0,
        delay_ticks=1,
        seed=seed,
    )
    assert boot["forward_counts"] == {"vlm": 1, "dit": 4}
    save("bootstrap", boot["actions"])
    for index, plan in enumerate(plans):
        tick, delay, age = plan["tick"], plan["delay"], plan["age"]
        timed(
            "vision",
            index,
            backend.vision,
            observation=plan["visual"],
            capture_s=1000.0 + (tick - age) * 0.05,
            source_tick=tick - age,
            requested_tick=tick - age,
            return_features=False,
        )
        output = timed(
            "plan",
            index,
            backend.plan,
            observation={"state": plan["observation"]["state"]},
            request_tick=tick,
            delay_ticks=delay,
            committed_actions=plan["committed"],
            state_capture_s=1000.0 + tick * 0.05,
        )
        assert output["audit"]["image_delay_ticks"] == age
        assert output["audit"]["forward_counts"] == {"vlm": 0, "dit": 1}
        assert output["audit"]["extra_buffer_shift"] == 0
        save(index, output["actions"])
        audits.append(output["audit"])
    if evidence:
        arrays["cuda_rng_state"] = torch.cuda.get_rng_state().numpy().copy()
    return arrays, timings, audits


def differences(actual, reference):
    import numpy as np

    result = {}
    for key, value in actual.items():
        error = np.abs(value.astype(np.float64) - reference[key].astype(np.float64))
        result[key] = {
            "max_abs": float(error.max()),
            "mean_abs": float(error.mean()),
            "exact": bool(np.array_equal(value, reference[key])),
            "finite": bool(np.isfinite(value).all()),
        }
    return result


def attention_runtime(core):
    backbone = core.model.backbone.model
    return {
        "backbone": {
            name: getattr(module.config, "_attn_implementation", None)
            for name, module in (
                ("main", backbone),
                ("text", backbone.language_model),
                ("vision", backbone.visual),
            )
        },
        "action_head_processors": dict(
            Counter(
                type(block.attn1.processor).__name__
                for block in core.model.action_head.model.transformer_blocks
            )
        ),
    }


def trace_accounting(path, precision):
    """Durations of actual GPU operations, not recursive CPU operator timings."""
    events = json.loads(path.read_text())["traceEvents"]
    categories = ("kernel", "gpu_memcpy", "gpu_memset")
    selected = [
        event
        for event in events
        if event.get("ph") == "X" and event.get("cat") in categories
    ]
    assert selected, "The recorded trace has no CUDA operations"
    parts = {
        category: {
            "seconds": math.fsum(
                event["dur"] for event in selected if event["cat"] == category
            )
            / 1e6,
            "count": sum(event["cat"] == category for event in selected),
        }
        for category in categories
    }
    kernels = [event["name"] for event in selected if event["cat"] == "kernel"]
    integer = {}
    for bits, element, tile in (
        (8, "signedchar", "GemmShape<16,8,32>"),
        (4, "integer_subbyte<4,true>", "GemmShape<16,8,64>"),
    ):
        matches = [
            name
            for name in kernels
            if element in name.replace(" ", "") and tile in name.replace(" ", "")
        ]
        integer[str(bits)] = {
            "count": len(matches),
            "kernel_examples": sorted(set(matches))[:1],
        }
        expected = precision == f"w{bits}a{bits}"
        assert bool(matches) == expected, (precision, bits, integer[str(bits)])
    return {
        "source": "Separate profiled replay; Chrome trace durations are microseconds",
        "gpu_operation_sum_seconds": math.fsum(
            row["seconds"] for row in parts.values()
        ),
        "gpu_timeline_span_seconds": (
            max(event["ts"] + event["dur"] for event in selected)
            - min(event["ts"] for event in selected)
        )
        / 1e6,
        "parts": parts,
        "int_kernel_verification": integer,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-identity", type=Path, required=True)
    parser.add_argument("--tactics", type=Path)
    parser.add_argument("--group-tactics", type=Path)
    parser.add_argument("--vision-channels-last", action="store_true")
    parser.add_argument("--dit-cuda-graph", action="store_true")
    parser.add_argument("--layout-reference", type=Path)
    parser.add_argument("--episode", type=int, default=0)
    parser.add_argument("--start", type=int, default=20)
    parser.add_argument("--calls", type=int, default=6)
    parser.add_argument("--rounds", type=int, default=5)
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--seed", type=int, default=1000)
    parser.add_argument("--video-backend", default="torchcodec")
    parser.add_argument("--trace", action="store_true")
    args = parser.parse_args()
    assert not args.vision_channels_last or args.layout_reference is not None
    args.output.mkdir(parents=True, exist_ok=True)
    assert args.rounds > 0 and args.warmup > 0 and args.calls > 0

    import numpy as np
    import torch
    import transformers
    import triton
    from libero_experiment_utils import checkpoint_identity
    from libero_inference_backend import Backend
    from serve_libero_protocol import load_core

    from coexecution.groot_optimization import GrootOptimizations, OptimizationConfig

    assert torch.cuda.is_available() and torch.cuda.device_count() == 1
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    core = load_core(args.checkpoint, args.output, "cuda:0")
    assert core.model.config.streaming and core.model.config.action_horizon == 40
    assert all(
        core.modality_configs[modality].delta_indices == [0]
        for modality in ("video", "state", "language")
    ), "This replay packs one current frame and state per input"
    initial, plans, episode = observations_and_prefixes(
        core, args.dataset, args.episode, args.start, args.calls, args.video_backend
    )
    backend = Backend(core, "pir2", args.output)
    category = int(
        core._collate_state_only({"state": initial["state"]})[0]["embodiment_id"].item()
    )
    modes = [
        (
            "bf16",
            OptimizationConfig(
                vision_channels_last=args.vision_channels_last,
                dit_graph=args.dit_cuda_graph,
            ),
        ),
        (
            "fusion_bf16",
            OptimizationConfig(
                fusion=True,
                vision_channels_last=args.vision_channels_last,
                dit_graph=args.dit_cuda_graph,
            ),
        ),
        (
            "fusion_w8a8",
            OptimizationConfig(
                precision="w8a8",
                fusion=True,
                scope="all",
                category_id=category,
                dit_graph=args.dit_cuda_graph,
                tactics=args.tactics,
                group_tactics=args.group_tactics,
                vision_channels_last=args.vision_channels_last,
            ),
        ),
        (
            "fusion_w4a4",
            OptimizationConfig(
                precision="w4a4",
                fusion=True,
                scope="all",
                category_id=category,
                dit_graph=args.dit_cuda_graph,
                tactics=args.tactics,
                group_tactics=args.group_tactics,
                vision_channels_last=args.vision_channels_last,
            ),
        ),
    ]
    manifest = {
        "scope": "Serial dataset observation replay; no simulated environment, no closed-loop success claim",
        "timing": {
            "host_wall_seconds": "Unprofiled local call wall time with stream synchronization; includes event instrumentation and Backend request log I/O; excludes loading, adapter setup, warmup, evidence copies, RPC and simulator",
            "gpu_stream_span_seconds": "CUDA event elapsed on the actual Backend private stream; includes CPU submission gaps between GPU work and is not GPU operation sum",
            "gpu_operation_sum_seconds": "Only when --trace: sum of kernel, gpu_memcpy and gpu_memset durations from a separate profiled replay; not unprofiled latency",
            "gpu_timeline_span_seconds": "Only when --trace: first GPU operation start through final operation end, including idle gaps; not the sum of operation durations",
        },
        "checkpoint": checkpoint_identity(args.checkpoint),
        "source_identity": json.loads(args.source_identity.read_text()),
        "source_identity_sha256": hashlib.sha256(
            args.source_identity.read_bytes()
        ).hexdigest(),
        "current_adapter_sha256": {
            name: hashlib.sha256(
                (ROOT / name).read_bytes().replace(b"\r\n", b"\n")
            ).hexdigest()
            for name in (
                "coexecution/groot_optimization.py",
                "scripts/libero_model_loading.py",
                "scripts/serve_libero_protocol.py",
            )
        },
        "current_adapter_hash_scope": "UTF-8 source bytes with CRLF normalized to LF",
        "runtime": {
            "torch": torch.__version__,
            "cuda_build": torch.version.cuda,
            "triton": triton.__version__,
            "transformers": transformers.__version__,
            "attention": attention_runtime(core),
        },
        "gpu": str(torch.cuda.get_device_properties(0)),
        "episode": episode,
        "dataset": str(args.dataset.resolve()),
        "start": args.start,
        "seed": args.seed,
        "clock": "Synthetic 20 Hz replay ticks; demonstration frames are fixed inputs, not a paced closed-loop deployment",
        "graph": args.dit_cuda_graph,
        "vision_layout": "channels_last_3d"
        if args.vision_channels_last
        else "original",
        "backend_cuda_stream": backend.stream.cuda_stream,
        "condition_grouping": False,
        "tactics": {
            "default_tactic": 0,
            "policy": "Optional named single and exact-member group overrides; unmatched modules use tactic 0; no coverage or Long presets",
            "files": {
                name: (
                    {
                        "path": str(path.resolve()),
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    }
                    if path is not None
                    else None
                )
                for name, path in (
                    ("single", args.tactics),
                    ("group", args.group_tactics),
                )
            },
        },
        "mode_order": [name for name, _ in modes],
        "requests": [
            {
                "tick": p["tick"],
                "action_delay": p["delay"],
                "image_age": p["age"],
                "frame_hashes": backend.frame_hashes(p["visual"]),
                "prefix_sha256": hashlib.sha256(p["committed"].tobytes()).hexdigest(),
            }
            for p in plans
        ],
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    layout_reference = None
    if args.layout_reference:
        assert args.vision_channels_last
        prior = json.loads((args.layout_reference / "manifest.json").read_text())
        for key in ("checkpoint", "episode", "start", "seed", "requests"):
            assert prior[key] == manifest[key], ("Layout reference mismatch", key)
        with np.load(args.layout_reference / "bf16" / "outputs.npz") as archive:
            layout_reference = {key: archive[key] for key in archive.files}
    reference = None
    summary = {}
    with torch.inference_mode(), torch.cuda.stream(backend.stream):
        for name, config in modes:
            target = args.output / name
            target.mkdir(exist_ok=True)
            backend.output = target
            with GrootOptimizations(core, config) as optimized:
                attention = attention_runtime(core)
                assert (
                    attention["backbone"]
                    == manifest["runtime"]["attention"]["backbone"]
                )
                for _ in range(args.warmup):
                    replay(backend, initial, plans, args.seed)
                first = None
                for iteration in range(args.rounds):
                    arrays, timings, audits = replay(backend, initial, plans, args.seed)
                    if first is None:
                        first = arrays
                        np.savez(target / "outputs.npz", **arrays)
                    repeat = differences(arrays, first)
                    assert all(row["exact"] for row in repeat.values()), repeat
                    with (target / "timings.jsonl").open("a") as handle:
                        handle.write(
                            json.dumps(
                                {
                                    "iteration": iteration,
                                    "timings": timings,
                                    "audits": audits,
                                }
                            )
                            + "\n"
                        )
                if reference is None:
                    reference = first
                    if layout_reference is not None:
                        layout_error = differences(first, layout_reference)
                        assert all(row["finite"] for row in layout_error.values())
                        (args.output / "layout-comparison.json").write_text(
                            json.dumps(
                                {
                                    "scope": "Same checkpoint and replay inputs; Conv3D layout changes floating-point rounding; task quality is unmeasured",
                                    "reference": str(args.layout_reference),
                                    "errors": layout_error,
                                },
                                indent=2,
                            )
                            + "\n"
                        )
                error = differences(first, reference)
                assert all(row["finite"] for row in error.values()), error
                if name == "fusion_bf16":
                    assert all(row["exact"] for row in error.values()), error
                summary[name] = {
                    "errors_vs_bf16": error,
                    "optimization": optimized.evidence(),
                    "runtime_attention": attention,
                }
                if args.trace:
                    with torch.profiler.profile(
                        activities=[
                            torch.profiler.ProfilerActivity.CPU,
                            torch.profiler.ProfilerActivity.CUDA,
                        ]
                    ) as trace:
                        replay(backend, initial, plans, args.seed, evidence=False)
                    trace_path = target / "trace.json"
                    trace.export_chrome_trace(str(trace_path))
                    summary[name]["profiled_replay"] = trace_accounting(
                        trace_path, config.precision
                    )
            (args.output / "summary.json").write_text(
                json.dumps(summary, indent=2) + "\n"
            )
            print(name, "complete", flush=True)
        restored, _, _ = replay(backend, initial, plans, args.seed)
        restoration_reference = (
            layout_reference if layout_reference is not None else reference
        )
        assert all(
            row["exact"]
            for row in differences(restored, restoration_reference).values()
        )
        backend.reset({"seed": args.seed})
    manifest["status"] = "complete"
    manifest["restored_bf16_exact"] = True
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print("STREAMING_CHECKPOINT_REPLAY_PASSED", flush=True)


if __name__ == "__main__":
    main()
