"""Normalize measured streaming replay traces; never render before all inputs exist.

Uses the profiler-visualizer renderer and the sorted-bar presentation adaptation
from pir2-nongemm-study/scripts/refresh_four_stage_view.py. The old
skill_breakdown.py example-category regrouping is intentionally not used.
"""

import argparse
import colorsys
import csv
import hashlib
import importlib.util
import json
import math
import re
import statistics
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SKILL = Path(
    "references/profiler-visualizer"
)
DEFAULT_REFERENCE = Path(
    "third_party/robotics-the-speedup-paradox/src/robotics_bench/profiling/breakdown.py"
)
MODES = {
    "fusion_bf16": "Fusion BF16",
    "fusion_w8a8": "Fusion + W8A8",
    "fusion_w4a4": "Fusion + W4A4",
}
GPU_CATEGORIES = {"kernel", "gpu_memcpy", "gpu_memset"}
NS = "{http://www.w3.org/2000/svg}"
ET.register_namespace("", NS[1:-1])
ALIASES = {
    "_rope_kernel": (
        "Owned pointwise fusion",
        "coexecution/fused_ops.py:35",
        "RoPE rotation and multiply/add",
    ),
    "adaln_modulation_bf16": (
        "Owned pointwise fusion",
        "coexecution/csrc/adaln_modulation.cu:17",
        "BF16 scale/shift; normalization reduction is separate",
    ),
    "_prepare_condition": (
        "Owned pointwise fusion",
        "coexecution/groot_pointwise.py:29",
        "SiLU lookup and attention masks; no quantization",
    ),
    "_square_fp32_kernel": (
        "Normalization and reductions",
        "coexecution/fused_ops.py:177",
        "FP32 square producer for RMSNorm",
    ),
    "_rms_tail_kernel": (
        "Normalization and reductions",
        "coexecution/fused_ops.py:184",
        "RMSNorm reciprocal sqrt, scaling and weight",
    ),
    "_modulation_kernel": (
        "Owned pointwise fusion",
        "coexecution/groot_fusion.py:20",
        "BF16 affine modulation; includes flattened per-token streaming rows",
    ),
    "_silu_gate": (
        "Owned pointwise fusion",
        "coexecution/groot_pointwise.py:20",
        "SiLU lookup multiplied by gate; no quantization",
    ),
}
INTEGER_ALIAS = (
    "Quantization and packing",
    "coexecution/csrc/integer_dispatch.cu:12",
    "Row absmax/scale, optional activation, INT8/INT4 quantization and packing",
)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    Path(path).write_text(
        json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def classify(event, reference):
    original = reference.category(event)
    name = event["name"]
    alias = ALIASES.get(name) if event.get("cat") == "kernel" else None
    if event.get("cat") == "kernel" and name.startswith(
        ("void prepare_integer<8>(", "void prepare_integer<4>(")
    ):
        alias = INTEGER_ALIAS
    return (
        (alias[0], original, alias[1], alias[2])
        if alias
        else (
            original,
            original,
            "reference.category(event)",
            "Unchanged pinned reference rule",
        )
    )


def attribution(events):
    """GPU->CPU external ID / launch correlation->enclosing replay annotation.

    No GPU timestamp containment is used: asynchronous kernels can outlive their
    Python range. Missing or conflicting associations remain unassigned.
    """
    ranges = [
        e
        for e in events
        if e.get("ph") == "X"
        and e.get("cat") == "user_annotation"
        and e.get("name", "").startswith("replay::")
    ]
    counts = Counter(e["name"].split("::", 1)[1] for e in ranges)
    external, correlation = defaultdict(set), defaultdict(set)
    for event in events:
        if event.get("ph") != "X" or event.get("cat") in (
            GPU_CATEGORIES | {"gpu_user_annotation"}
        ):
            continue
        matching = {
            parent["name"].split("::", 1)[1]
            for parent in ranges
            if (event.get("pid"), event.get("tid"))
            == (parent.get("pid"), parent.get("tid"))
            and parent["ts"] <= event["ts"]
            and event["ts"] + event.get("dur", 0)
            <= parent["ts"] + parent["dur"] + 0.001
        }
        args = event.get("args", {})
        if "External id" in args:
            external[args["External id"]].update(matching)
        if (
            event.get("cat") in {"cuda_runtime", "cuda_driver"}
            and "correlation" in args
        ):
            correlation[args["correlation"]].update(matching)
    mapped = []
    for event in events:
        if event.get("ph") != "X" or event.get("cat") not in GPU_CATEGORIES:
            continue
        args = event.get("args", {})
        candidates = external.get(args.get("External id"), set()) | correlation.get(
            args.get("correlation"), set()
        )
        phase = next(iter(candidates)) if len(candidates) == 1 else "unassigned"
        mapped.append((event, phase))
    return mapped, counts


def timing_summary(path):
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    values = defaultdict(lambda: defaultdict(list))
    counts = Counter()
    for row in rows:
        by_kind = defaultdict(list)
        for item in row["timings"]:
            by_kind[item["kind"]].append(item)
        current_counts = Counter({kind: len(items) for kind, items in by_kind.items()})
        if counts:
            assert current_counts == counts, (
                "Replay request counts changed between rounds"
            )
        counts = current_counts
        for field in ("host_wall_seconds", "gpu_stream_span_seconds"):
            values["replay_call_sum"][field].append(
                math.fsum(x[field] for x in row["timings"]) * 1000
            )
            for kind, items in by_kind.items():
                values[kind][field].extend(x[field] * 1000 for x in items)
    result = {}
    for kind, fields in values.items():
        result[kind] = {}
        for field, samples in fields.items():
            result[kind][field.replace("_seconds", "_ms")] = {
                "samples": samples,
                "count": len(samples),
                "median": statistics.median(samples),
                "mean": statistics.mean(samples),
                "min": min(samples),
                "max": max(samples),
            }
    return result, counts


def sorted_render(renderer, input_path, output_dir, timestamp, timings, scope, graph):
    """Only bar geometry and presentation labels differ from the skill renderer."""
    import cairosvg

    document = read(input_path)
    artifacts = renderer.render_file(
        input_path, output_dir, prefix=f"spatial-pir2-{scope}", timestamp=timestamp
    )
    svg_path = Path(artifacts["svg"])
    tree = ET.parse(svg_path)
    svg = tree.getroot()
    texts = list(svg.findall(NS + "text"))
    backgrounds = [
        e
        for e in svg.findall(NS + "rect")
        if e.get("height") == "50" and e.get("rx") == "4"
    ]
    assert len(backgrounds) == len(document["profiles"])
    bar_orders = {}
    for profile, background in zip(document["profiles"], backgrounds):
        y, x, width = (float(background.get(key)) for key in ("y", "x", "width"))
        for element in list(svg):
            if (
                element.tag == NS + "rect"
                and float(element.get("y", "-1")) == y
                and element.find(NS + "title") is not None
                or element.tag == NS + "text"
                and float(element.get("y", "-1")) == y + 31
                and float(element.get("x", "0")) >= x
            ):
                svg.remove(element)
        components = sorted(
            profile["components"], key=lambda item: (-item["value"], item["name"])
        )
        bar_orders[profile["name"]] = [
            item["name"] for item in components if item["value"] > 0
        ]
        for item in components:
            if not item["value"]:
                continue
            share = item["value"] / profile["total"]
            width_part = width * share
            rectangle = ET.SubElement(
                svg,
                NS + "rect",
                {
                    "x": f"{x:.2f}",
                    "y": str(y),
                    "width": f"{width_part:.2f}",
                    "height": "50",
                    "fill": renderer._component_color(item["name"]),
                },
            )
            ET.SubElement(
                rectangle, NS + "title"
            ).text = f"{item['name']}: {item['value']:.6f} ms ({share * 100:.2f}%)"
            if width_part >= 75:
                label = ET.fromstring(
                    renderer._text(
                        x + width_part / 2,
                        y + 31,
                        f"{share * 100:.1f}%",
                        size=13,
                        weight=700,
                        fill="#FFFFFF",
                        anchor="middle",
                    )
                )
                label.tag = NS + "text"
                svg.append(label)
            x += width_part
        value_label = next(
            e
            for e in texts
            if float(e.get("x", "-1")) == 72 and float(e.get("y", "-1")) == y + 45
        )
        value_label.text = f"GPU op sum: {profile['total']:.2f} ms"
        mode = next(mode for mode, label in MODES.items() if label == profile["name"])
        kind = "replay_call_sum" if scope == "replay" else scope
        wall = timings[mode][kind]["host_wall_ms"]["median"]
        prefix = "Replay calls" if scope == "replay" else "Call median"
        extra = ET.fromstring(
            renderer._text(
                72,
                y + 66,
                f"{prefix}: {wall:.2f} ms | DiT Graph {'ON' if graph else 'OFF'}",
                size=13,
                fill="#43515D",
            )
        )
        extra.tag = NS + "text"
        svg.append(extra)
    table_header = next(e for e in texts if e.text == "Current - baseline")
    table_y = float(table_header.get("y"))
    table_order = renderer._component_order(renderer.normalize_document(document))
    centers = [552 + 796 / len(MODES) * (i + 0.5) for i in range(len(MODES))]
    for element in list(svg.findall(NS + "text")):
        y, x = float(element.get("y", "0")), float(element.get("x", "0"))
        if table_y <= y <= table_y + 60 + 43 * len(table_order):
            if x == 1528:
                svg.remove(element)
                continue
            index = next(
                (i for i, center in enumerate(centers) if abs(x - center) < 0.1), None
            )
            if index is not None:
                element.set("x", str(552 + 976 / len(MODES) * (index + 0.5)))
                if y == table_y:
                    element.set("font-size", "16")
        if element.text and element.text.startswith("Scale:"):
            element.text = "Each bar = 100% of its GPU work"
        replacements = {
            "Measured breakdown": "Operator share by stage",
            "Components": "Operator details: time and share",
            "Component": "Operator category (common order)",
        }
        if element.text in replacements:
            element.text = replacements[element.text]
    tree.write(svg_path, encoding="utf-8", xml_declaration=True)

    def css_color(match):
        h, s, light = map(float, match.groups())
        rgb = colorsys.hls_to_rgb(h / 360, light / 100, s / 100)
        return "#" + "".join(f"{round(c * 255):02x}" for c in rgb)

    svg_text = re.sub(
        r"hsl\((\d+) (\d+)% (\d+)%\)", css_color, svg_path.read_text(encoding="utf-8")
    )
    png_path = svg_path.with_suffix(".png")
    cairosvg.svg2png(bytestring=svg_text.encode(), write_to=str(png_path))
    manifest_path = Path(artifacts["manifest"])
    manifest = read(manifest_path)
    manifest["presentation"] = {
        "kind": "User-requested sorted bars; unchanged skill table order and colors",
        "bar_orders": bar_orders,
        "table_order": table_order,
        "graph": graph,
        "scope": scope,
    }
    manifest.update(
        output_png=str(png_path),
        output_svg_sha256=digest(svg_path),
        output_png_sha256=digest(png_path),
        adapter_sha256=digest(__file__),
    )
    write(manifest_path, manifest)
    return {**artifacts, "png": str(png_path)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("--skill", type=Path, default=DEFAULT_SKILL)
    parser.add_argument("--reference", type=Path, default=DEFAULT_REFERENCE)
    parser.add_argument("--render", action="store_true")
    parser.add_argument(
        "--history",
        action="store_true",
        help="Also render the measured-history ledger PNG",
    )
    parser.add_argument("--current-mode", choices=MODES, default="fusion_w8a8")
    args = parser.parse_args()
    required = [args.run / "manifest.json", args.run / "summary.json"]
    required += [
        args.run / mode / file
        for mode in MODES
        for file in ("trace.json", "timings.jsonl")
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        print(
            json.dumps(
                {"status": "pending", "missing": missing, "rendered": False}, indent=2
            )
        )
        return
    manifest = read(args.run / "manifest.json")
    assert manifest.get("status") == "complete" and manifest["restored_bf16_exact"], (
        "Replay and BF16 restoration must complete before reporting"
    )
    assert type(manifest["graph"]) is bool and manifest["condition_grouping"] is False
    graph = manifest["graph"]
    execution = (
        "Serial | DiT CUDA Graph ON" if graph else "Serial eager | CUDA Graph OFF"
    )
    assert all(mode in read(args.run / "summary.json") for mode in MODES), (
        "Replay is not complete"
    )
    reference = module(args.reference, "reference_breakdown")
    renderer = module(
        args.skill / "scripts/render_profile_breakdown.py", "skill_breakdown"
    )
    timestamp = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
    output = args.run / f"{timestamp}_profile_report"
    output.mkdir(exist_ok=False)
    scopes, timings, audit, kernel_rows, sources = defaultdict(list), {}, {}, [], []
    phase_complete = True
    expected_counts = Counter(
        bootstrap=1, vision=len(manifest["requests"]), plan=len(manifest["requests"])
    )
    for mode, label in MODES.items():
        path = args.run / mode / "trace.json"
        mapped, counts = attribution(read(path)["traceEvents"])
        assert mapped, "No measured GPU operations"
        timings[mode], timing_counts = timing_summary(args.run / mode / "timings.jsonl")
        assert timing_counts == expected_counts
        groups, kernel_totals = (
            defaultdict(lambda: defaultdict(float)),
            defaultdict(lambda: [0, 0.0]),
        )
        for event, phase in mapped:
            duration = event["dur"] / 1000
            assert math.isfinite(duration) and duration >= 0
            category, original, basis, description = classify(event, reference)
            groups["replay"][category] += duration
            groups[phase][category] += duration
            key = (
                phase,
                event["cat"],
                event["name"],
                category,
                original,
                basis,
                description,
            )
            kernel_totals[key][0] += 1
            kernel_totals[key][1] += duration
        complete = (
            counts == expected_counts
            and not groups["unassigned"]
            and set(groups) <= {"replay", "bootstrap", "vision", "plan", "unassigned"}
        )
        phase_complete &= complete
        for scope, values in groups.items():
            if not values or scope == "unassigned":
                continue
            divisor = 1 if scope == "replay" else counts[scope]
            scopes[scope].append(
                {
                    "name": label,
                    "total": math.fsum(values.values()) / divisor,
                    "components": [
                        {"name": name, "value": value / divisor}
                        for name, value in values.items()
                    ],
                }
            )
        audit[mode] = {
            "annotation_counts": counts,
            "expected_counts": expected_counts,
            "phase_attribution_complete": complete,
            "unassigned_gpu_ms": math.fsum(groups["unassigned"].values()),
            "gpu_event_count": len(mapped),
            "gpu_total_ms": math.fsum(groups["replay"].values()),
        }
        for key, values in kernel_totals.items():
            kernel_rows.append([mode, *key, *values])
        sources.extend(
            {"path": str(file.resolve()), "sha256": digest(file)}
            for file in (path, args.run / mode / "timings.jsonl")
        )
    if not phase_complete:
        scopes = {"replay": scopes["replay"]}
    prefix = output / timestamp
    write(str(prefix) + "_timing_summary.json", timings)
    write(str(prefix) + "_phase_attribution.json", audit)
    alias_sources = sorted(
        {item[1].rsplit(":", 1)[0] for item in [*ALIASES.values(), INTEGER_ALIAS]}
    )
    write(
        str(prefix) + "_provenance.json",
        {
            "sources": sources,
            "reference": {
                "path": str(args.reference),
                "sha256": digest(args.reference),
                "pinned_revision": read(ROOT / "sources.lock.json")["sources"][
                    "robotics-kernels"
                ]["revision"],
            },
            "alias_sources": {
                source: digest(ROOT / source) for source in alias_sources
            },
            "skill_renderer": {
                "path": str(args.skill / "scripts/render_profile_breakdown.py"),
                "sha256": digest(args.skill / "scripts/render_profile_breakdown.py"),
            },
            "manifest": manifest,
            "normalizer_sha256": digest(__file__),
        },
    )
    classification_csv = Path(str(prefix) + "_kernel_classification.csv")
    with classification_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "mode",
                "phase",
                "event_cat",
                "kernel",
                "category",
                "reference_category",
                "basis",
                "description",
                "count",
                "total_ms",
            ]
        )
        writer.writerows(kernel_rows)
    rule_lines = [
        "# Classification and measurement basis",
        "",
        "Drawing format: profiler-visualizer. Categories: pinned Speedup Paradox breakdown.py plus source-verified aliases; no skill-official taxonomy is claimed.",
        "",
        "Each GPU kernel/memcpy/memset duration is counted once. CPU operator durations are excluded. Unclassified GPU work is retained. Fused attention is not counted a second time as GEMM.",
        "",
        "Phase attribution uses GPU External id and CUDA-launch correlation to CPU events enclosed by replay:: annotations, never GPU timestamp containment. If any GPU event is unassigned or range counts differ, only total replay is rendered.",
        "",
        "Call counts and CPU enclosing ranges use only user_annotation. The paired gpu_user_annotation ranges in these traces do not represent extra calls and are not GPU operations.",
        "",
        f"Workload: {dict(expected_counts)}. Replay totals are not one policy call. Phase profiles are mean GPU work per call within one diagnostic replay. Timing samples are separate unprofiled calls; replay call-wall sums exclude inter-call evidence work and are not elapsed simulation or closed-loop latency.",
        "",
        "| Alias | Reference category used | Verified source | Meaning |",
        "|---|---|---|---|",
    ]
    for name, (category, source, description) in ALIASES.items():
        rule_lines.append(f"| `{name}` | {category} | {source} | {description} |")
    rule_lines.append(
        f"| `void prepare_integer<8/4>(...)` | {INTEGER_ALIAS[0]} | {INTEGER_ALIAS[1]} | {INTEGER_ALIAS[2]} |"
    )
    Path(str(prefix) + "_classification_rules.md").write_text(
        "\n".join(rule_lines) + "\n", encoding="utf-8"
    )
    artifacts = {}
    for scope, profiles in scopes.items():
        title = (
            "Spatial piR2 | Fixed replay"
            if scope == "replay"
            else f"Spatial piR2 | Mean {scope} call"
        )
        aggregation = (
            f"one replay: 1 bootstrap + {expected_counts['vision']} vision + {expected_counts['plan']} plan"
            if scope == "replay"
            else f"mean of {expected_counts[scope]} {scope} calls in one diagnostic replay"
        )
        document = reference.document(
            profiles,
            [classification_csv.name, Path(str(prefix) + "_provenance.json").name],
            title,
        )
        document["metric"]["aggregation"] = aggregation
        document["subtitle"] = f"Checkpoint 500 | {execution} | Condition grouping OFF"
        document["context"] = {
            "hardware": manifest["gpu"],
            "classification": "Reference rules + documented source aliases",
            "vision layout": manifest.get("vision_layout", "original"),
            "DiT CUDA Graph": "ON for all plotted stages"
            if graph
            else "OFF for all plotted stages",
        }
        document["notes"] += [
            f"All plotted stages share vision layout {manifest.get('vision_layout', 'original')}; layout is held fixed and is not attributed to quantization.",
            "Each bar is independently sorted by its own share. Category colors and detail rows use one common order.",
            "GPU op sums are diagnostic work, not elapsed latency. Unprofiled local-call timings are reported separately.",
            "Fixed demonstration replay; no simulator, RPC or closed-loop success measurement. Quantized action quality remains unaccepted.",
            "One trace per mode; unprofiled sample counts and spread are preserved in the timing summary. Modes run in fixed order.",
        ]
        input_path = output / f"{timestamp}_{scope}_breakdown.json"
        write(input_path, document)
        renderer.normalize_document(document)
        if args.render:
            artifacts[scope] = sorted_render(
                renderer, input_path, output, timestamp, timings, scope, graph
            )
    ledger = {
        "schema_version": 1,
        "title": "Spatial piR2 streaming replay | Checkpoint 500",
        "evidence_kind": "measured",
        "current_run_id": args.current_mode,
        "protocols": [
            {
                "id": "fixed-replay",
                "label": "Fixed demonstration replay",
                "original_state_id": "fusion_bf16",
                "workload": {
                    "checkpoint": manifest["checkpoint"],
                    "requests": dict(expected_counts),
                    "seed": manifest["seed"],
                    "inputs": manifest["requests"],
                    "timing_boundary": manifest["timing"]["host_wall_seconds"],
                },
                "environment": {
                    "hardware": manifest["gpu"],
                    "mode_order": manifest["mode_order"],
                    "operating_conditions": "GPU clocks/power stability not established by this replay manifest",
                },
                "metric": {
                    "name": "Sum of fixed replay local-call wall times",
                    "unit": "ms",
                    "statistic": "median",
                },
            }
        ],
        "optimizations": [
            {"id": "fusion", "label": "Operator fusion", "scope": "shared"},
            *(
                [{"id": "dit_graph", "label": "DiT CUDA Graph", "scope": "shared"}]
                if graph
                else []
            ),
            {"id": "integer", "label": "Integer quantization", "scope": "precision"},
        ],
        "states": [],
        "runs": [],
        "comparisons": [],
        "notes": [
            "Separate protocol from historical Long/Flow benchmarks; no historical cross-workload speedup.",
            "Measurement times are not recorded in the input; recorded_at is report creation time.",
            "Five or other recorded repeats are preserved. Fixed mode order and absent operating-condition telemetry do not establish a reviewed comparison cohort; comparison edges remain pending.",
            "Original unfused BF16 remains available in raw replay evidence; the requested view shows only fusion BF16 and quantized stages.",
            "Random-weight kernel contracts and demonstration replay do not establish closed-loop quality. Current run is explicitly selected, not chosen by fastest timing.",
            "The wall-time metric sums individually timed calls, excluding inter-call evidence work. It is neither complete replay elapsed time nor one policy-call latency.",
        ],
    }
    for mode, label in MODES.items():
        integer = mode != "fusion_bf16"
        state = {
            "id": mode,
            "label": label,
            "revision": (
                f"base {manifest['source_identity']['base_commit'][:12]}; "
                "local source and adapter hashes in provenance"
            ),
            "precision": "BF16" if not integer else mode.split("_", 1)[1].upper(),
            "classification": "lossy" if integer else "reference",
            "status": "experimental",
            "description": f"{execution}; explicit layout and tactic configuration in provenance; task quality unmeasured",
            "shared_config": {
                "operator_fusion": True,
                "graph": graph,
                "condition_grouping": False,
                "vision_layout": manifest.get("vision_layout", "original"),
            },
            "active_optimizations": [
                "fusion",
                *(["dit_graph"] if graph else []),
                *(["integer"] if integer else []),
            ],
        }
        if integer:
            state["parent_id"] = "fusion_bf16"
        ledger["states"].append(state)
        ledger["runs"].append(
            {
                "id": mode,
                "state_id": mode,
                "protocol_id": "fixed-replay",
                "cohort_id": "fixed-order-session-pending-review",
                "recorded_at": datetime.now(timezone.utc).isoformat(),
                "samples": timings[mode]["replay_call_sum"]["host_wall_ms"]["samples"],
                "sources": [
                    str((args.run / mode / "timings.jsonl").resolve()),
                    str((args.run / "summary.json").resolve()),
                ],
                "quality": {"status": "unmeasured"},
                "profile": {
                    "path": f"{timestamp}_replay_breakdown.json",
                    "name": label,
                },
            }
        )
    ledger_path = output / f"{timestamp}_ledger.json"
    write(ledger_path, ledger)
    subprocess.run(
        [
            sys.executable,
            str(args.skill / "scripts/render_optimization_history.py"),
            str(ledger_path),
            "--validate-only",
        ],
        check=True,
    )
    if args.history:
        subprocess.run(
            [
                sys.executable,
                str(args.skill / "scripts/render_optimization_history.py"),
                str(ledger_path),
                "--output-dir",
                str(output),
            ],
            check=True,
        )
    write(output / f"{timestamp}_artifacts.json", artifacts)
    print(
        json.dumps(
            {
                "status": "complete",
                "output": str(output),
                "phase_attribution_complete": phase_complete,
                "artifacts": artifacts,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
