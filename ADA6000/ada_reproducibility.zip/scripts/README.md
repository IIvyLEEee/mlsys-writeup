# Replay and intermediate-data scripts

The measured runtime is piR2 commit `11d9ddb6da0087ba9404850033646a43cf8045c2` plus `progressive.patch`. It is not a benchmark of the later inspected `517f5189e3075c2b28a164f4b788bea387bfa4b2` revision.

## Contents

- `progressive.patch`: the experiment's progressive-quantization implementation and tests.
- `progressive_replay.py`: actual matched BF16 plus eleven-tier measurement driver.
- `replay_spatial_checkpoint.py`: actual fixed-sequence data/replay helper.
- `replay_profile_report.py`: actual trace-attribution helper. Its two unused-in-this-replay standalone-renderer defaults were changed from machine-specific absolute paths to relative example locations. The `attribution` function is unchanged.
- `shape-tactics-candidate.json`: the measured tactic configuration.
- `sources.lock.json`: the repository dependency declaration; it is not proof that every live external dependency Git revision was verified.
- `export_intermediate.py`: new CPU-only exporter used to create the shareable tables. This is postprocessing, not a new benchmark.

`../data/provenance.json` and `../data/sanitization.json` record the original and distributed hashes. Original evidence files are unchanged. Checkpoints, data, native binaries and full profiler traces are not included in this upload.

## Prepared-environment replay recipe

Use an independent checkout of the measured base, inspect/apply the patch, and install the repository's required CUDA/GR00T/integer-backend dependencies. The observed runtime was PyTorch 2.9.0+cu128, CUDA 12.8, Triton 3.5.0 on RTX 6000 Ada. External integer-backend revision/dirty status and selected binary identity were not fully resolved in the original run; observed module and candidate library hashes are retained in provenance.

The helpers intentionally retain their original repository-root assumption: put the three Python replay helpers in `<PIR2_REPO>/.local/` before execution. Do not run them directly from the Overleaf project's `scripts/` directory. Put the tactic JSON beside them. In a fresh checkout:

```sh
git checkout 11d9ddb6da0087ba9404850033646a43cf8045c2
git apply --check /path/to/package/scripts/progressive.patch
git apply /path/to/package/scripts/progressive.patch
mkdir -p .local
cp /path/to/package/scripts/progressive_replay.py .local/
cp /path/to/package/scripts/replay_spatial_checkpoint.py .local/
cp /path/to/package/scripts/replay_profile_report.py .local/
cp /path/to/package/scripts/shape-tactics-candidate.json .local/
```

Configure `PYTHONPATH` to include the checkout root, its `scripts/`, `.local/`, the prepared GR00T Python source directory, and the integer-backend `src/` directory. Model-relative offline assets, including the required vision/language config, must be available as required by the checkpoint. The original run used one visible GPU and local/offline model loading. Then, from the checkout root:

```sh
CUDA_VISIBLE_DEVICES=0 \
GROOT_HF_LOCAL_FIRST=1 GROOT_PATCH_MISTRAL=1 HF_HUB_OFFLINE=1 \
NO_ALBUMENTATIONS_UPDATE=1 TOKENIZERS_PARALLELISM=false \
python .local/progressive_replay.py \
  --checkpoint /path/to/checkpoint-500 \
  --dataset /path/to/groot-libero-spatial \
  --shape-tactics .local/shape-tactics-candidate.json \
  --output /path/to/new-trial-directory \
  --rounds 3 --samples 5
```

The output directory must not already exist. This is a prepared-environment recipe; it was not validated as a new clean-install reproduction while producing the report. Do not infer closed-loop quality from fixed-sequence action deviations.

## Regenerate shareable intermediate data

```sh
python export_intermediate.py \
  --trial /path/to/original/evidence/trial-02 \
  --repo /path/to/measured/pir2-checkout \
  --output /path/to/shareable-report
```

This command writes only `data/`, `scripts/` and `evidence/` under its output. The exporter checks the raw sample count, reproduces all host medians, and verifies the diagnosis's compressed-trace hashes before exporting. No model execution is performed.
