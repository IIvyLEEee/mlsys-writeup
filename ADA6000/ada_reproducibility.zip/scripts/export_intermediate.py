"""Build shareable intermediate tables from the original trial evidence.

Usage: python export_intermediate.py --trial TRIAL_DIR --repo PIR2_CHECKOUT --output PACKAGE_DIR
Only writes PACKAGE_DIR/{data,scripts,evidence}; never changes source evidence.
"""
import argparse
import csv
import hashlib
import json
import re
import statistics
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def clean_log(text):
    # Preserve traceback suffixes and numerical results while removing host identities.
    text = re.sub(r"/home/[^/\s]+/piR2/\.local/streaming-spatial-20261010/upstream/learning/Isaac-GR00T", "<GR00T_ROOT>", text)
    text = re.sub(r"/home/[^/\s]+/pir2-progressive-20261013/\.local/base", "<BASE_CHECKOUT>", text)
    text = re.sub(r"/home/[^/\s]+/pir2-progressive-20261013", "<EXPERIMENT_CHECKOUT>", text)
    text = re.sub(r"/home/[^/\s]+", "<HOME>", text)
    return text


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trial", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    trial, repo, root = args.trial, args.repo, args.output
    data, scripts, evidence = (root / name for name in ("data", "scripts", "evidence"))
    for directory in (data, scripts, evidence):
        directory.mkdir(parents=True, exist_ok=True)
    summary = read(trial / "summary.json")
    manifest = read(trial / "manifest.json")
    validation = read(trial / "validation.json")
    diagnosis_name = "diagnosis/20261013_162215_latency_causes.json"
    diagnosis = read(trial / diagnosis_name)
    raw = [json.loads(line) for line in (trial / "samples.jsonl").read_text().splitlines()]
    modes = ["bf16"] + [f"t{i}" for i in range(11)]

    tiers, rounds, samples = [], [], []
    for mode in modes:
        item = summary[mode]
        host = item["latency_ms"]["plan"]["host_wall_seconds"]
        tiers.append({"mode": mode, "tier": item["tier"],
            "w4_candidate_count": item["w4_count"] if mode != "bf16" else "",
            "candidate_count": 192, "w4_candidate_percent": item["w4_fraction"] * 100 if mode != "bf16" else "",
            "plan_sample_count": host["n"], "plan_median_ms": host["median"],
            "plan_p10_ms": host["p10"], "plan_p90_ms": host["p90"],
            "separate_profile_plan_calls": 6,
            "gpu_operation_sum_mean_ms": item["profile"]["phase_mean_gpu_sum_ms"]["plan"],
            "action_mae_native": item["action_mae"], "action_rmse_native": item["action_rmse"],
            "action_max_abs_native": item["action_max_abs"]})
        for round_index, median in enumerate(item["round_plan_medians_ms"]):
            rounds.append({"mode": mode, "round_1based": round_index + 1,
                "order_position_1based": manifest["orders"][round_index].index(mode) + 1,
                "replay_count": 5, "plan_sample_count": 30, "plan_median_ms": median})
    for replay_index, row in enumerate(raw):
        for call in row["calls"]:
            if call["kind"] != "plan":
                continue
            samples.append({"mode": row["mode"], "round_1based": row["round"] + 1,
                "replay_in_round_1based": row["sample"] + 1, "replay_record_1based": replay_index + 1,
                "plan_index_0based": call["index"], "host_wall_ms": call["host_wall_seconds"] * 1000,
                "cuda_event_stream_span_ms": call["gpu_stream_span_seconds"] * 1000})
    assert len(raw) == 180 and len(samples) == 1080
    for item in tiers:
        observed = [r["host_wall_ms"] for r in samples if r["mode"] == item["mode"]]
        assert len(observed) == 90 and statistics.median(observed) == item["plan_median_ms"]
    write_csv(data / "tiers.csv", tiers)
    write_csv(data / "rounds.csv", rounds)
    write_csv(data / "latency_samples.csv", samples)

    breakdown, counts, delta = [], [], []
    categories = sorted({category for row in diagnosis.values() for category in row["graph_category_ms"]})
    for mode, row in diagnosis.items():
        for category in categories:
            breakdown.append({"mode": mode, "scope": "dit_graph", "category": category,
                "mean_gpu_operation_sum_ms": row["graph_category_ms"].get(category, 0), "profile_plan_count": 6})
            counts.append({"mode": mode, "scope": "dit_graph", "category": category,
                "mean_gpu_event_count": row["graph_category_counts"].get(category, 0), "profile_plan_count": 6})
        breakdown.append({"mode": mode, "scope": "dit_graph", "category": "TOTAL",
            "mean_gpu_operation_sum_ms": row["means"]["graph_gpu_work_ms"], "profile_plan_count": 6})
        counts.append({"mode": mode, "scope": "dit_graph", "category": "TOTAL",
            "mean_gpu_event_count": row["means"]["graph_kernel_count"], "profile_plan_count": 6})
    for scope, field in [("whole_plan", "plan_category_ms"), ("dit_graph", "graph_category_ms")]:
        for category in categories:
            before = diagnosis["t7"][field].get(category, 0)
            after = diagnosis["t8"][field].get(category, 0)
            delta.append({"scope": scope, "category": category, "t7_mean_ms": before,
                "t8_mean_ms": after, "delta_ms": after - before})
        total_before = sum(diagnosis["t7"][field].values())
        total_after = sum(diagnosis["t8"][field].values())
        delta.append({"scope": scope, "category": "TOTAL", "t7_mean_ms": total_before,
            "t8_mean_ms": total_after, "delta_ms": total_after - total_before})
    write_csv(data / "graph_breakdown.csv", breakdown)
    write_csv(data / "graph_counts.csv", counts)
    write_csv(data / "t7_t8_delta.csv", delta)
    write_json(data / "latency_causes.json", diagnosis)

    roles = ("attn1.to_q", "attn1.to_k", "attn1.to_v", "attn1.to_out.0", "ff.net.0.proj", "ff.net.2")
    candidates = [f"action_head.model.transformer_blocks.{block}.{role}" for block in range(32) for role in roles]
    sites = {"schema_version": 1, "candidate_definition": "32 blocks x 6 Linear sites; not parameter or FLOP coverage",
        "protocol": "groot32-cosmos-role-order-v1", "tiers": {}}
    for mode in modes[1:]:
        coverage = validation[mode]["evidence"]["coverage"]
        mapping = {name: coverage["site_bits"][name] for name in candidates}
        assert sum(bits == 4 for bits in mapping.values()) == summary[mode]["w4_count"]
        sites["tiers"][mode] = {"candidate_bits": mapping, "w4_candidate_count": coverage["w4_candidate_count"],
            "noncandidate_selected_linear_bits": {key: value for key, value in sorted(coverage["site_bits"].items()) if key not in candidates},
            "category_linears": coverage["category_linears"], "category_bits": coverage["category_bits"],
            "active_projection_groups": coverage["active_projection_groups"]}
    write_json(data / "selected_sites.json", sites)

    source_names = ["summary.json", "manifest.json", "validation.json", "samples.jsonl", "profiles.json", "weight-loading.json", diagnosis_name]
    originals = {"trial-02/" + name: sha(trial / name) for name in source_names}
    for mode in modes:
        originals[f"trial-02/{mode}/trace.json.gz"] = sha(trial / mode / "trace.json.gz")
    for mode, row in diagnosis.items():
        assert row["trace_sha256"] == originals[f"trial-02/{mode}/trace.json.gz"]
    assets = []
    for name in ("progressive_replay.py", "replay_spatial_checkpoint.py", "replay_profile_report.py", "shape-tactics-candidate.json", "progressive.patch"):
        original = repo / ".local" / name
        content = original.read_bytes()
        changes = []
        if name == "replay_profile_report.py":
            text = content.decode("utf-8")
            text = re.sub(r'"[A-Za-z]:/[^"\n]*/profiler-visualizer"', '"references/profiler-visualizer"', text)
            text = re.sub(r'"[A-Za-z]:/[^"\n]*/robotics-the-speedup-paradox/src/robotics_bench/profiling/breakdown.py"', '"third_party/robotics-the-speedup-paradox/src/robotics_bench/profiling/breakdown.py"', text)
            content = text.encode("utf-8")
            changes = ["Replaced two machine-specific standalone rendering defaults with relative example locations; attribution function and measurement logic unchanged."]
        destination = scripts / name
        destination.write_bytes(content)
        assets.append({"package_path": "scripts/" + name, "original_relative_path": ".local/" + name,
            "original_sha256": sha(original), "distributed_sha256": sha(destination), "sanitization": changes})
    (scripts / "sources.lock.json").write_bytes((repo / "sources.lock.json").read_bytes())
    for name in ("full-contracts.log", "contracts.log", "node-tests.log", "gpu-tests.log", "base-gpu-test.log"):
        source = trial.parent / name
        destination = evidence / name
        destination.write_text(clean_log(source.read_text(encoding="utf-8")), encoding="utf-8")
        assets.append({"package_path": "evidence/" + name, "original_relative_path": "evidence/" + name,
            "original_sha256": sha(source), "distributed_sha256": sha(destination),
            "sanitization": ["Replaced host-specific absolute traceback paths with symbolic root placeholders; results and stack content retained."]})

    limitations = [
        "One fixed episode and six plan calls repeatedly replayed; no closed-loop success or task-quality conclusion.",
        "Ninety timings per configuration are repeated calls of the same six-request sequence, not independent tasks. p10/p90 are empirical sample quantiles, not confidence intervals.",
        "GPU operation duration sum is the mean over six calls in one separate profiled replay per configuration; it cannot be subtracted from the unprofiled wall-time median to estimate CPU time.",
        "All quantized tiers keep selected VLM Linear modules in W8A8, while the reference is full BF16; action deviations therefore include the VLM quantization effect and are not isolated DiT errors.",
        "W4 coverage counts 192 candidate Linear sites, not parameters, FLOPs or GPU kernels. Attention core remains floating; T10 is not a fully INT4 model.",
        "Unprofiled host-call timing includes CUDA-event instrumentation, stream synchronization, Backend bookkeeping and request-log I/O. It excludes separately timed VLM updates, RPC, simulator and scheduling.",
        "Git revision/dirty state and selected native binary for the external integer backend are unknown; the expected revision and observed module/library hashes are retained separately.",
        "The trace-based explanations are consistent with the code path but no independent ablation isolates each suspected cause; profiler submission timings do not causally account for all unprofiled wall-time differences.",
        "T9 has the lowest pooled median, but round variation and overlapping sample ranges do not establish a stable best configuration.",
        "The existing GPU suite has three dit_graph parameter failures; only its BF16 case was rerun and reproduced on the pristine base.",
        "Dependencies, checkpoint assets and dataset are not bundled. A portable clean-environment rerun has not been performed. Device clocks/power/temperature time series were not recorded."
    ]
    backend = validation["t8"]["evidence"]["backend"]
    provenance = {
        "schema_version": 1, "experiment_date": "2026-10-13", "timezone": "Asia/Shanghai",
        "title": "RTX 6000 Ada streaming GR00T/piR2 progressive W8A8 to partial W4A4 replay",
        "code": {"repository": "https://github.com/Ther-nullptr/piR2",
            "measured_base_commit": "11d9ddb6da0087ba9404850033646a43cf8045c2",
            "patch": "scripts/progressive.patch", "patch_sha256": sha(scripts / "progressive.patch"),
            "measured_code_state": "Measured base commit plus uncommitted progressive patch; not a benchmark of the subsequently checked upstream commit.",
            "upstream_checked_commit": "517f5189e3075c2b28a164f4b788bea387bfa4b2",
            "source_sha256_recorded_at_measurement": manifest["source_sha256"],
            "dependency_lock": "scripts/sources.lock.json", "dependency_lock_sha256": sha(scripts / "sources.lock.json")},
        "hardware": {"gpu": "NVIDIA RTX 6000 Ada Generation", "compute_capability": "8.9", "multiprocessors": 142,
            "total_memory_MB_as_recorded": 48519, "l2_cache_MB_as_recorded": 96, "gpu_visible_to_process": 1},
        "runtime": {"torch": manifest["torch"], "cuda": manifest["cuda"], "triton": backend["runtime"]["triton"],
            "attention": manifest["attention"]},
        "checkpoint": {"label": "Spatial streaming checkpoint-500", "runtime_path_parameter": "--checkpoint <CHECKPOINT_DIR>",
            "sha256": manifest["checkpoint"]["sha256"]},
        "external_integer_backend": backend,
        "protocol": {"id": "groot32-cosmos-role-order-v1", "description": manifest["protocol"],
            "reference": "https://github.com/thu-ee-acts-lab/robotics-the-speedup-paradox/blob/239b4a3ef2268048571c9f508ad5700f98398c2f/src/robotics_bench/optimizations/progressive.py",
            "scope": manifest["scope"], "fixed_precision": manifest["fixed_precision"], "episode": manifest["episode"],
            "episode_index": 0, "start_frame": 20, "seed": 1000, "batch_size": 1, "action_horizon": 40,
            "plan_calls_per_replay": 6, "dit_forward_calls_per_plan": 1, "vlm_forward_calls_per_plan": 0,
            "bootstrap_calls_per_replay": 1, "separate_vision_updates_per_replay": 6,
            "request_delays_ticks": [1, 3, 5, 1, 3, 5], "image_ages_ticks": [0, 2, 5, 0, 2, 5],
            "rounds": 3, "replays_per_round_per_configuration": 5, "timed_plans_per_configuration": 90,
            "warmup_replays_per_configuration_selection": 3, "configuration_orders": manifest["orders"],
            "profile_replays_per_configuration": 1, "profile_plan_calls_per_configuration": 6,
            "baseline": manifest["baseline"], "exclusions": manifest["exclusions"],
            "action_error_scope": "Flattened actions_0 through actions_5 versus matched full BF16; bootstrap excluded; native model output units",
            "shape_tactics": "scripts/shape-tactics-candidate.json", "shape_tactics_sha256": manifest["shape_tactics_sha256"]},
        "privacy": "No host IP, login name, absolute private workspace path, GPU UUID, credentials, checkpoint tensors or input observations are included in this metadata.",
        "original_evidence_sha256": originals, "distributed_assets": assets, "limitations": limitations}
    write_json(data / "provenance.json", provenance)
    per_mode = {}
    for mode in modes:
        errors = validation[mode]["vs_bf16"]
        per_mode[mode] = {"all_captured_outputs_finite": all(value["finite"] for value in errors.values()),
            "times_and_cuda_rng_match_bf16_exactly": all(value["exact"] for key, value in errors.items() if key.startswith("times_") or key == "cuda_rng_state"),
            "all_captured_outputs_match_bf16_exactly": all(value["exact"] for value in errors.values()),
            "integer_kernel_counts_full_profile_replay": summary[mode]["profile"]["integer_kernel_counts"],
            "action_mae_native": summary[mode]["action_mae"], "action_rmse_native": summary[mode]["action_rmse"],
            "action_max_abs_native": summary[mode]["action_max_abs"]}
    validations = {"schema_version": 1, "weight_loading": read(trial / "weight-loading.json"),
        "checkpoint_replay": {"status": manifest["status"], "restored_bf16_exact": manifest["restored_bf16_exact"],
            "per_mode": per_mode, "repeatability": "A separate captured evidence replay at each configuration selection was asserted bitwise exact across three rounds. The 90 timing calls per mode were not all individually captured and compared.",
            "kernel_assertions": "Profiler contains INT8 GEMMs for all quantized modes; INT4 GEMMs for T1-T10 only; no integer GEMMs for the full BF16 reference. Counts cover the whole profiled replay, not just one plan."},
        "tests": {"python_lightweight": {"passed": 248, "failed": 0, "log": "evidence/full-contracts.log"},
            "node": {"passed": 59, "failed": 0, "log": "evidence/node-tests.log"},
            "gpu_suite": {"passed": 19, "failed": 3, "log": "evidence/gpu-tests.log", "new_progressive_cases_passed": [0, 2, 8, 10],
                "failed_cases": ["tests/gpu/test_groot_streaming_gpu.py::test_real_streaming_head_fusion_state_reset_and_integer_kernels[dit_graph-" + name + "]" for name in ("bf16", "w8a8", "w4a4")],
                "failure_message": "RuntimeError: Optimized policy requires serial submissions"},
            "pristine_base_reproduction": {"tested_case": "dit_graph-bf16 only", "failed": 1, "deselected": 5,
                "log": "evidence/base-gpu-test.log", "scope": "Only BF16 was rerun on pristine base; no claim that all three parameters were independently reproduced there."}},
        "attachment_audit": {"raw_replay_records": len(raw), "exported_plan_samples": len(samples),
            "all_exported_medians_equal_original_summary": True, "diagnosis_trace_hashes_match": True,
            "no_new_gpu_benchmark_performed_for_report": True}}
    write_json(data / "validation_summary.json", validations)
    write_json(data / "sanitization.json", {"assets": assets,
        "metadata": "Constructed a whitelist-based provenance summary; original manifest private paths and GPU identifiers were not copied. Source/evidence digests are retained for auditing.",
        "sample_data": "Only plan timing numbers, tier labels, round/replay indices and precision maps were exported; model weights, observations and action arrays are not included."})
    print(json.dumps({"tiers": len(tiers), "round_rows": len(rounds), "plan_sample_rows": len(samples), "files": [str(path.relative_to(root)) for folder in (data, scripts, evidence) for path in sorted(folder.glob('*'))]}, indent=2))


if __name__ == "__main__":
    main()
