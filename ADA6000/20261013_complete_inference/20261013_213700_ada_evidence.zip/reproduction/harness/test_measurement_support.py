"""CPU-only input/provenance guards; this file does not import a model or CUDA."""

from pathlib import Path
import json
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from measurement_support import (
    array_hashes, clear_resume_failure, convolution_profile, read_matched_input,
    sdpa_constructor_options, verify_source_manifest,
)


class MatchedInputTests(unittest.TestCase):
    def test_convolution_guard_counts_cpu_only_and_detects_fallback(self):
        def event(name, device, duration):
            return SimpleNamespace(name=name, device_type=device, cpu_time_total=duration)

        events = [event("aten::cudnn_convolution", "DeviceType.CPU", 100.0),
                  event("aten::cudnn_convolution", "DeviceType.CPU", 200.0),
                  event("aten::cudnn_convolution", "DeviceType.CUDA", 4000.0)]
        profile = convolution_profile(events)
        self.assertEqual(profile["events"]["aten::cudnn_convolution"],
                         {"count": 2, "cpu_time_total_us": 300.0})
        self.assertTrue(profile["cudnn_present"])
        self.assertFalse(profile["slow_conv_dilated3d_present"])
        profile = convolution_profile(events + [event("aten::slow_conv_dilated3d", "DeviceType.CPU", 900.0)])
        self.assertTrue(profile["slow_conv_dilated3d_present"])

    def test_resume_archives_failure_before_clearing_live_fields(self):
        summary = {"error": "current", "failed_at": "time", "prior_failure": {"error": "older"}}
        clear_resume_failure(summary)
        self.assertNotIn("error", summary)
        self.assertNotIn("failed_at", summary)
        self.assertEqual(summary["prior_failure"], {"error": "current", "failed_at": "time"})
        self.assertEqual(summary["prior_failures"], [{"error": "older"}])
        clear_resume_failure(summary)
        self.assertEqual(len(summary["prior_failures"]), 1)

    def test_real_thor_fixture_roundtrip_and_tamper_rejection(self):
        root = Path(__file__).parent
        reference = json.loads((root / "thor-reference.json").read_text())
        initial, plan, arrays = read_matched_input(root / "prepared-input.npz", reference)
        self.assertEqual(array_hashes(arrays), reference["input_array_hashes"])
        self.assertEqual(initial["language"]["annotation.human.action.task_description"],
                         [["pick up the black bowl next to the cookie box and place it on the plate"]])
        self.assertEqual(plan["committed"].shape, (1, 7))
        self.assertEqual(initial["video"]["image"].shape, (1, 1, 256, 256, 3))
        self.assertTrue(np.array_equal(initial["video"]["image"], plan["visual"]["video"]["image"]))
        self.assertFalse(np.shares_memory(initial["video"]["image"], plan["visual"]["video"]["image"]))
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "changed.npz"
            arrays["video.image"][0, 0, 0, 0, 0] ^= 1
            np.savez(path, **arrays)
            with self.assertRaisesRegex(ValueError, "video.image"):
                read_matched_input(path, reference)

    def test_source_manifest_rejects_drift_and_path_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "source.py").write_text("value = 1\n")
            (root / "source-manifest.json").write_text(json.dumps({"files": {"source.py": "wrong"}}))
            with self.assertRaisesRegex(ValueError, "Source drift"):
                verify_source_manifest(root)
            (root / "source-manifest.json").write_text(json.dumps({"files": {"../outside": "wrong"}}))
            with self.assertRaisesRegex(ValueError, "escapes"):
                verify_source_manifest(root)

    def test_sdpa_is_a_constructor_option_and_factory_is_restored_on_error(self):
        calls = []

        class FakeModel:
            @classmethod
            def from_pretrained(cls, *pos, **kwargs):
                calls.append((pos, kwargs))
                raise RuntimeError("intentional load failure")

        original = FakeModel.__dict__["from_pretrained"]
        groot = ModuleType("gr00t")
        groot_model = ModuleType("gr00t.model")
        policy = ModuleType("gr00t.policy")
        policy.gr00t_policy = SimpleNamespace(AutoModel=FakeModel)
        groot.model = groot_model
        groot.policy = policy
        transformers = ModuleType("transformers")
        transformers.AutoConfig = SimpleNamespace(
            from_pretrained=lambda _path: SimpleNamespace(use_flash_attention=True)
        )
        with patch.dict("sys.modules", {"gr00t": groot, "gr00t.model": groot_model,
                                       "gr00t.policy": policy, "transformers": transformers}):
            with self.assertRaisesRegex(RuntimeError, "intentional"):
                with sdpa_constructor_options():
                    FakeModel.from_pretrained("checkpoint", output_loading_info=True)
        self.assertIs(FakeModel.__dict__["from_pretrained"], original)
        options = calls[0][1]
        self.assertFalse(options["config"].use_flash_attention)
        self.assertEqual(options["transformers_loading_kwargs"]["attn_implementation"], "sdpa")
        self.assertTrue(options["output_loading_info"])


if __name__ == "__main__":
    unittest.main()
