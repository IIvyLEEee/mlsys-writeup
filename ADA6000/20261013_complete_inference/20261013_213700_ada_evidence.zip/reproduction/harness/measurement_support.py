"""Input and constructor checks for the matched Ada/Thor latency experiment."""

from collections import Counter
from contextlib import contextmanager
import copy
import hashlib
import json
from pathlib import Path

import numpy as np


W4_COUNTS = [0, 6, 16, 21, 33, 43, 48, 80, 128, 160, 192]


def array_hashes(arrays):
    return {
        name: {
            "shape": list(value.shape),
            "dtype": str(value.dtype),
            "sha256": hashlib.sha256(value.tobytes()).hexdigest(),
        }
        for name, value in arrays.items()
    }


def read_matched_input(path, reference):
    """Restore Thor's already-decoded exact CPU arrays, without a video decoder."""
    with np.load(path, allow_pickle=False) as archive:
        arrays = {key: archive[key].copy() for key in archive.files}
    observed = array_hashes(arrays)
    expected = reference["input_array_hashes"]
    if observed != expected:
        changed = sorted(
            key for key in observed.keys() | expected.keys()
            if observed.get(key) != expected.get(key)
        )
        raise ValueError(f"Thor input array mismatch: {changed}")
    initial = {"video": {}, "state": {}, "language": {}}
    for key, value in arrays.items():
        if key == "committed":
            continue
        group, name = key.split(".", 1)
        if group not in initial:
            raise ValueError(f"Unknown input group: {group}")
        # The original policy input uses a nested string list, not an ndarray.
        initial[group][name] = value.tolist() if group == "language" else value
    assert arrays["committed"].shape == (1, 7)
    assert all(initial[group] for group in initial)
    plan = {
        "tick": 0, "delay": 1, "age": 0,
        "observation": copy.deepcopy(initial),
        "visual": copy.deepcopy(initial),
        "committed": arrays["committed"].copy(),
    }
    return initial, plan, arrays


def attention_runtime(core):
    backbone = core.model.backbone.model
    return {
        "backbone": {
            name: getattr(module.config, "_attn_implementation", None)
            for name, module in (
                ("main", backbone),
                ("text", backbone.language_model),
                ("vision", backbone.visual),
            )
        },
        "action_head_processors": dict(Counter(
            type(block.attn1.processor).__name__
            for block in core.model.action_head.model.transformer_blocks
        )),
    }


@contextmanager
def sdpa_constructor_options():
    """Pass existing model-constructor options; never replace a forward method.

    load_core has no constructor-kwargs parameter, so temporarily route its
    AutoModel factory through an explicit AutoConfig and loading kwargs. Its
    strict weight-loading check remains in force, and the factory is restored
    even if model loading fails. The checkpoint files are never modified.
    """
    import gr00t.model  # noqa: F401 -- registers the pinned model AutoConfig.
    from gr00t.policy import gr00t_policy as policy_module
    from transformers import AutoConfig

    model_class = policy_module.AutoModel
    original_descriptor = model_class.__dict__.get("from_pretrained")
    original = model_class.from_pretrained

    def configured(*pos, **kwargs):
        if not pos:
            raise ValueError("Expected a positional checkpoint path")
        config = AutoConfig.from_pretrained(pos[0])
        config.use_flash_attention = False
        kwargs["config"] = config
        kwargs["transformers_loading_kwargs"] = {
            "trust_remote_code": True,
            "attn_implementation": "sdpa",
        }
        return original(*pos, **kwargs)

    model_class.from_pretrained = configured
    try:
        yield
    finally:
        if original_descriptor is None:
            del model_class.from_pretrained
        else:
            model_class.from_pretrained = original_descriptor


def assert_quantized_scope(evidence, tier):
    coverage = evidence["coverage"]
    if tier is None:
        return
    assert evidence["backend"]["backend_id"] == "pir2_integer", evidence["backend"]
    assert coverage["candidate_count"] == 192, coverage
    assert len(coverage["linears"]) == 192, coverage
    assert coverage["w4_candidate_count"] == W4_COUNTS[tier], coverage
    assert coverage["noncandidate_precision"] == "bf16", coverage
    assert coverage["progressive_protocol"] == "groot32-cosmos-role-order-dit-only-v1"
    bits = coverage["site_bits"]
    assert set(bits.values()) <= {4, 8}
    assert sum(value == 4 for value in bits.values()) == W4_COUNTS[tier]
    assert set(coverage["linears"]) == set(bits)
    assert all(name.startswith("action_head.model.transformer_blocks.") for name in bits)


def convolution_profile(events):
    """Nested CPU event totals from a separate profile, never GPU wall latency."""
    names = (
        "aten::conv3d", "aten::convolution", "aten::_convolution",
        "aten::cudnn_convolution", "aten::slow_conv_dilated3d",
    )
    result = {name: {"count": 0, "cpu_time_total_us": 0.0} for name in names}
    for event in events:
        if str(event.device_type).split(".")[-1] != "CPU" or event.name not in result:
            continue
        row = result[event.name]
        row["count"] += 1
        row["cpu_time_total_us"] += float(event.cpu_time_total)
    return {
        "scope": "separate single-policy profiler; nested CPU event totals, not additive GPU wall time",
        "events": result,
        "cudnn_present": result["aten::cudnn_convolution"]["count"] > 0,
        "slow_conv_dilated3d_present": result["aten::slow_conv_dilated3d"]["count"] > 0,
    }


def clear_resume_failure(summary):
    if "error" in summary or "failed_at" in summary:
        if "prior_failure" in summary:
            summary.setdefault("prior_failures", []).append(summary["prior_failure"])
        summary["prior_failure"] = {
            key: summary.pop(key) for key in ("error", "failed_at") if key in summary
        }


def verify_source_manifest(root, filename="source-manifest.json"):
    root = Path(root).resolve()
    path = root / filename
    manifest = json.loads(path.read_text(encoding="utf-8"))
    for relative, expected in manifest["files"].items():
        candidate = (root / relative).resolve()
        if not candidate.is_relative_to(root):
            raise ValueError(f"Source manifest escapes experiment root: {relative}")
        actual = hashlib.sha256(candidate.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f"Source drift: {relative}")
    return manifest
