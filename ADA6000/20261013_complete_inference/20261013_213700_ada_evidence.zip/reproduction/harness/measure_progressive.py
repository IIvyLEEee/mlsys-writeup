"""Matched Ada INT8/INT4 scan, sharing Thor's full-call timing/state protocol."""
import argparse
import copy
import datetime as dt
import fcntl
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import random
import statistics
import sys
import time
import traceback
from dataclasses import asdict

import numpy as np
import torch

from coexecution.libero.backend import Backend, KEYS
from coexecution.libero.service import load_core
from coexecution.optimization.config import OptimizationConfig
from coexecution.optimization.session import GrootOptimizations
from measurement_support import (
    array_hashes, assert_quantized_scope, attention_runtime, clear_resume_failure,
    convolution_profile, read_matched_input,
    sdpa_constructor_options, verify_source_manifest,
)
from scripts.libero_experiment_utils import checkpoint_identity
from scripts.libero_protocol_scheduler import project_commands


def now():
    return dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


class EvidenceBackend(Backend):
    def raw(self, actions):
        self.decoded_cpu_chunk = np.concatenate([actions[k][0] for k in KEYS], axis=-1)
        raw = project_commands(self.decoded_cpu_chunk)
        self.full_cpu_chunk = raw
        return raw


def clone_value(value):
    if isinstance(value, torch.Tensor):
        return value.clone()
    if isinstance(value, dict) or hasattr(value, 'items'):
        return {k: clone_value(v) for k, v in value.items()}
    return copy.deepcopy(value)


def snapshot(backend):
    core = backend.core
    head = core.model.action_head
    backend.stream.synchronize()
    with core._vl_cache_lock:
        vl = clone_value(core._vl_cache)
        vl_id = core._vl_cache_id
        vl_time = core._vl_cache_t_image_capture
    return {
        'buffer': head._stream_buf.clone(),
        'times': head._stream_buf_t.clone(),
        'vl': vl, 'vl_id': vl_id, 'vl_time': vl_time,
        'anchor': backend.anchor, 'meta': copy.deepcopy(backend.cache_meta),
        'python_rng': random.getstate(), 'numpy_rng': np.random.get_state(),
        'cpu_rng': torch.get_rng_state(), 'cuda_rng': torch.cuda.get_rng_state(0),
    }


def restore(backend, state):
    core = backend.core
    head = core.model.action_head
    head._stream_buf = state['buffer'].clone()
    head._stream_buf_t = state['times'].clone()
    with core._vl_cache_lock:
        core._vl_cache = backend.BatchFeature(clone_value(state['vl']))
        core._vl_cache_id = state['vl_id']
        core._vl_cache_t_image_capture = state['vl_time']
    backend.anchor = state['anchor']
    backend.cache_meta = copy.deepcopy(state['meta'])
    random.setstate(state['python_rng'])
    np.random.set_state(state['numpy_rng'])
    torch.set_rng_state(state['cpu_rng'])
    torch.cuda.set_rng_state(state['cuda_rng'], 0)
    backend.stream.synchronize()


def graph_stats(core):
    pending = [core.model.action_head.model.forward]
    seen = set()
    while pending:
        obj = pending.pop()
        if id(obj) in seen:
            continue
        seen.add(id(obj))
        if type(obj).__name__ == 'DitGraphs':
            return {
                'captures': sum(g.captures for g in obj.graphs.values()),
                'replays': sum(g.replays for g in obj.graphs.values()),
                'signatures': [str(g.signature) for g in obj.graphs.values()],
            }
        pending.extend(cell.cell_contents for cell in getattr(obj, '__closure__', ()) or ())
    return {'captures': 0, 'replays': 0, 'signatures': []}


def call_plan(backend, plan):
    return backend.plan(
        observation={'state': plan['observation']['state']},
        request_tick=0, delay_ticks=1, committed_actions=plan['committed'],
        state_capture_s=1000.0,
        visual={'observation': plan['visual'], 'capture_s': 1000.0,
                'source_tick': 0, 'requested_tick': 0},
    )


def validate_result(backend, result):
    audit = result['audit']
    assert audit['forward_counts'] == {'vlm': 1, 'dit': 1}, audit
    assert audit['image_delay_ticks'] == 0 and audit['extra_buffer_shift'] == 0, audit
    assert not audit['buffer_restarted'], audit
    assert backend.full_cpu_chunk.shape == (40, 7), backend.full_cpu_chunk.shape
    assert np.isfinite(backend.full_cpu_chunk).all(), 'Non-finite CPU action chunk'
    assert np.isfinite(backend.decoded_cpu_chunk).all(), 'Non-finite decoded action chunk'


def prepare(backend, initial, seed):
    random.seed(seed)
    np.random.seed(seed)
    boot = backend.bootstrap(initial, capture_s=1000.0, delay_ticks=1, seed=seed)
    assert boot['forward_counts'] == {'vlm': 1, 'dit': 4}, boot['forward_counts']
    return snapshot(backend)


def errors(actual, expected):
    assert actual.shape == expected.shape
    assert np.isfinite(actual).all() and np.isfinite(expected).all()
    delta = actual.astype(np.float64) - expected.astype(np.float64)
    norm = float(np.linalg.norm(expected))
    return {'shape': list(actual.shape), 'finite': True,
            'exact': bool(np.array_equal(actual, expected)),
            'max_abs': float(np.abs(delta).max()),
            'mean_abs': float(np.abs(delta).mean()),
            'rmse': float(np.sqrt(np.mean(delta ** 2))),
            'relative_l2': float(np.linalg.norm(delta) / norm) if norm else None}


def configs():
    shared = {'component': 'dit', 'fusion': True, 'dit_graph': True,
              'vision_channels_last': False}
    return {'original_bf16': OptimizationConfig(component='dit'),
            'bf16': OptimizationConfig(**shared),
            **{f'tier{tier:02}': OptimizationConfig(
                **shared, precision='w8a8', quant_tier=tier,
                norm_modulation_quant=True, residual_norm_quant=True,
            ) for tier in range(11)}}


def main(args):
    root = args.root.resolve()
    output = root / 'results/measurements'
    output.mkdir(parents=True, exist_ok=True)
    lock = (root / '.gpu-workload.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.cuda.set_device(0)
    assert torch.cuda.get_device_capability(0) == (8, 9), 'Expected RTX 6000 Ada SM89'
    checkpoint = args.checkpoint.resolve()
    cp_identity = checkpoint_identity(checkpoint)
    manifest = verify_source_manifest(root)
    thor = json.loads(args.thor_reference.read_text())
    assert cp_identity['sha256'] == thor['identity']['checkpoint']['sha256'], 'Thor checkpoint mismatch'
    initial, plan, input_arrays = read_matched_input(args.prepared_input, thor)
    import gr00t
    model_source_root = Path(gr00t.__file__).resolve().parent.parent
    model_manifest = verify_source_manifest(model_source_root, 'GROOT_SOURCE_MANIFEST.json')
    assert len(model_manifest['files']) == 75, 'Expected complete audited 75-file GR00T source package'
    runtime = {'torch': str(torch.__version__), 'cuda': torch.version.cuda,
               'cudnn': torch.backends.cudnn.version(),
               'cudnn_enabled': torch.backends.cudnn.enabled,
               'cudnn_benchmark': torch.backends.cudnn.benchmark,
               'cudnn_deterministic': torch.backends.cudnn.deterministic}
    package_versions = {}
    for package in ('torch', 'torchvision', 'triton', 'transformers', 'numpy',
                    'Pillow', 'safetensors', 'tokenizers', 'nvidia-cudnn-cu12'):
        try:
            package_versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            package_versions[package] = None
    modes = configs()
    identity = {'source_sha256': digest(root / 'source-manifest.json'),
                'model_source_manifest_sha256': digest(model_source_root / 'GROOT_SOURCE_MANIFEST.json'),
                'runtime': runtime, 'package_versions': package_versions,
                'checkpoint': cp_identity, 'configs': {k: asdict(v) for k, v in modes.items()},
                'harness_sha256': digest(Path(__file__)),
                'support_sha256': digest(Path(__file__).with_name('measurement_support.py')),
                'thor_reference_sha256': digest(args.thor_reference),
                'input_array_hashes': array_hashes(input_arrays),
                'constructor_options': {'use_flash_attention': False,
                                        'transformers_loading_kwargs': {'trust_remote_code': True, 'attn_implementation': 'sdpa'}},
                'seed': 42,
                'warmup': args.warmup, 'repeats': args.repeats, 'validation_seeds': [42, 0, 195]}
    identity_hash = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
    summary_file = output / 'summary.json'
    if summary_file.exists():
        summary = json.loads(summary_file.read_text())
        assert summary['identity_hash'] == identity_hash, 'Resume identity mismatch'
        clear_resume_failure(summary)
    else:
        summary = {'schema_version': 1, 'status': 'running', 'started_at': now(),
                   'identity': identity, 'identity_hash': identity_hash, 'modes': {},
                   'quality_modes': [],
                   'protocol': {
                       'name': 'GR00T DiT W8A8-to-W4A4 adaptation of reference progressive protocol; full fresh-vision plan',
                       'reference_revision': '239b4a3ef2268048571c9f508ad5700f98398c2f',
                       'model_base_revision': manifest['base_revision'],
                       'timing': 'prepared CPU observation -> Backend.plan -> CPU action; 1 VLM + 1 streaming DiT',
                       'includes': ['online activation packing', 'pre/postprocessing', 'request JSONL write'],
                       'excludes': ['model load', 'weight packing', 'compile', 'CUDA Graph capture',
                                    'warmup', 'bootstrap 1 VLM + 4 DiT', 'state reset', 'profiling'],
                       'state_reset': 'per-config bootstrap snapshot; clone buffers/cache and restore all RNG outside timing',
                       'validation': 'full 40x7 decoded continuous CPU action chunk and projected commands; per-config bootstrap error propagates; finite only guard',
                       'input': 'Spatial episode 0 frame 20; fresh visual; action delay1 image age0 fixed demo prefix',
                       'coverage': '192 structurally selected DiT Linear sites; not dynamic GEMM-call coverage',
                       'quantization_scope': '192 candidate DiT Linears only; VLM and noncandidate DiT remain BF16',
                       'optimization_bundle': 'Shared fusion=all and DiT Graph; integer tiers also use norm/modulation and residual/norm quantization fusion',
                       'quality': 'fixed-input replay diagnostics only; no closed-loop runs requested or performed',
                   },
                   'environment': {**runtime, 'package_versions': package_versions,
                                   'device': torch.cuda.get_device_name(0),
                                   'capability': list(torch.cuda.get_device_capability(0)),
                                   'python': sys.version, 'threads': torch.get_num_threads(),
                                   'interop_threads': torch.get_num_interop_threads(),
                                   'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES')},
                   }
    summary['status'] = 'running'
    save(summary_file, summary)
    try:
        load_started = time.perf_counter()
        with sdpa_constructor_options():
            core = load_core(checkpoint, output, 'cuda:0')
        summary['model_load_seconds'] = time.perf_counter() - load_started
        assert core.model.config.streaming is True
        assert core.model.config.action_horizon == len(core.modality_configs['action'].delta_indices) == 40
        summary['input_metadata'] = thor.get('input_metadata', {})
        summary['input_hashes'] = Backend.frame_hashes(initial)
        np.savez(output / 'prepared-input.npz', **input_arrays)
        summary['prepared_input_sha256'] = digest(output / 'prepared-input.npz')
        summary['source_prepared_input_sha256'] = digest(args.prepared_input)
        summary['input_array_hashes'] = array_hashes(input_arrays)
        summary['attention_runtime'] = attention_runtime(core)
        assert summary['attention_runtime'] == thor['attention_runtime'], 'Attention backend differs from Thor'
        assert set(summary['attention_runtime']['backbone'].values()) == {'sdpa'}
        summary['loaded_model_source'] = {
            name: {'file': str(Path(module.__file__).resolve()),
                   'sha256': digest(Path(module.__file__))}
            for name, module in sys.modules.copy().items()
            if name in ('gr00t.policy.decoupled_policy', 'gr00t.model.gr00t_n1d7.gr00t_n1d7',
                        'gr00t.model.modules.qwen3_backbone', 'gr00t.model.modules.dit')
        }
        for name, module in sys.modules.copy().items():
            if name.startswith('coexecution.') and getattr(module, '__file__', None):
                assert Path(module.__file__).resolve().is_relative_to(root), f'Unexpected runtime source: {name}'
        backend = EvidenceBackend(core, 'pir2', output)
        save(summary_file, summary)
        with torch.inference_mode(), torch.cuda.stream(backend.stream):
            for key, cfg in modes.items():
                if summary['modes'].get(key, {}).get('status') == 'complete':
                    print('RESUME_SKIP', key, flush=True)
                    continue
                mode_dir = output / key
                mode_dir.mkdir(exist_ok=True)
                backend.output = mode_dir
                row = {'status': 'preparing', 'config': asdict(cfg), 'started_at': now()}
                summary['modes'][key] = row
                save(summary_file, summary)
                start_prepare = time.perf_counter()
                with GrootOptimizations(core, cfg) as scope:
                    row['optimization'] = scope.evidence()
                    assert_quantized_scope(row['optimization'], cfg.quant_tier)
                    row['validation'] = {}
                    for seed in (42, 0, 195):
                        state = prepare(backend, initial, seed)
                        restore(backend, state)
                        validate_result(backend, call_plan(backend, plan))  # captures allowed here
                        actual = backend.full_cpu_chunk.copy()
                        decoded = backend.decoded_cpu_chunk.copy()
                        np.save(mode_dir / f'actions-seed{seed}.npy', actual)
                        np.save(mode_dir / f'decoded-seed{seed}.npy', decoded)
                        compare = {}
                        for ref in ('original_bf16', 'bf16'):
                            ref_path = output / ref / f'actions-seed{seed}.npy'
                            if ref_path.exists():
                                compare[ref] = errors(actual, np.load(ref_path))
                                compare[ref + '_decoded'] = errors(decoded, np.load(output / ref / f'decoded-seed{seed}.npy'))
                        restore(backend, state)
                        call_plan(backend, plan)
                        compare['repeat'] = errors(backend.full_cpu_chunk, actual)
                        compare['repeat_decoded'] = errors(backend.decoded_cpu_chunk, decoded)
                        assert compare['repeat']['exact'], f'Nondeterministic replay: {key} seed {seed}'
                        assert compare['repeat_decoded']['exact'], f'Nondeterministic decoded replay: {key} seed {seed}'
                        row['validation'][str(seed)] = compare
                        save(summary_file, summary)
                    state = prepare(backend, initial, 42)
                    for _ in range(args.warmup):
                        restore(backend, state)
                        call_plan(backend, plan)
                    row['preparation_seconds'] = time.perf_counter() - start_prepare
                    row['graph_before_timing'] = graph_stats(core)
                    if cfg.dit_graph:
                        assert row['graph_before_timing']['captures'] > 0, 'Graph not observed'
                    row.update(status='measuring', samples_ms=[])
                    save(summary_file, summary)
                    for index in range(args.repeats):
                        restore(backend, state)
                        started = time.perf_counter()
                        result = call_plan(backend, plan)
                        backend.stream.synchronize()
                        elapsed = (time.perf_counter() - started) * 1000
                        validate_result(backend, result)
                        row['samples_ms'].append(elapsed)
                        row['last_audit'] = result['audit']
                        after = graph_stats(core)
                        assert after['captures'] == row['graph_before_timing']['captures'], 'Graph capture inside timed region'
                        if cfg.dit_graph:
                            assert after['replays'] == row['graph_before_timing']['replays'] + index + 1, after
                        save(summary_file, summary)
                    row['graph_after_timing'] = graph_stats(core)
                    row['median_ms'] = statistics.median(row['samples_ms'])
                    row['min_ms'], row['max_ms'] = min(row['samples_ms']), max(row['samples_ms'])
                    row['status'] = 'profiling'
                    save(summary_file, summary)
                    for _ in range(3):
                        restore(backend, state)
                        call_plan(backend, plan)
                    restore(backend, state)
                    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                                           torch.profiler.ProfilerActivity.CUDA]) as prof:
                        with torch.profiler.record_function('progressive::single_policy'):
                            call_plan(backend, plan)
                            backend.stream.synchronize()
                    prof.export_chrome_trace(str(mode_dir / 'trace.json'))
                    row['profile'] = str(mode_dir / 'trace.json')
                    row['convolution_profile'] = convolution_profile(prof.events())
                    save(summary_file, summary)
                    assert row['convolution_profile']['cudnn_present'], 'Profile did not observe aten::cudnn_convolution'
                    assert not row['convolution_profile']['slow_conv_dilated3d_present'], 'BF16 Conv3D used slow_conv_dilated3d fallback'
                    row['optimization'] = scope.evidence()
                # Closing adapters must restore original source behavior.
                restored_state = prepare(backend, initial, 42)
                restore(backend, restored_state)
                call_plan(backend, plan)
                original = np.load(output / 'original_bf16/actions-seed42.npy')
                row['restoration'] = errors(backend.full_cpu_chunk, original)
                row['restoration_decoded'] = errors(backend.decoded_cpu_chunk, np.load(output / 'original_bf16/decoded-seed42.npy'))
                assert row['restoration']['exact'], 'Adapter restoration changed original output'
                assert row['restoration_decoded']['exact'], 'Adapter restoration changed decoded original output'
                row.update(status='complete', completed_at=now())
                for reference in ('original_bf16', 'bf16'):
                    if summary['modes'].get(reference, {}).get('median_ms'):
                        row[f'speedup_vs_{reference}'] = summary['modes'][reference]['median_ms'] / row['median_ms']
                save(mode_dir / 'result.json', row)
                save(summary_file, summary)
                print('MODE_COMPLETE', key, row['median_ms'], 'ms', now(), flush=True)
                del state, restored_state
                gc.collect()
                torch.cuda.empty_cache()
        summary.update(status='complete', completed_at=now())
        save(summary_file, summary)
    except BaseException:
        summary.update(status='failed', error=traceback.format_exc(), failed_at=now())
        save(summary_file, summary)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--prepared-input', type=Path, required=True)
    parser.add_argument('--thor-reference', type=Path, required=True)
    parser.add_argument('--warmup', type=int, default=3)
    parser.add_argument('--repeats', type=int, default=10)
    main(parser.parse_args())
