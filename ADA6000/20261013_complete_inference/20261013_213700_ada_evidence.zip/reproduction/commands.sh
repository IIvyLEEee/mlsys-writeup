#!/usr/bin/env bash
# Read and run in a prepared Linux GR00T dependency environment.
# Set these to independent work directories/assets. No secrets belong here.
set -euo pipefail
: "${PACKAGE:?set PACKAGE to this reproduction directory}"
: "${ROOT:?set ROOT to a NEW piR2 checkout directory}"
: "${GROOT_SOURCE:?set GROOT_SOURCE to a NEW Isaac-GR00T checkout directory}"
: "${CHECKPOINT:?set CHECKPOINT to the verified checkpoint-500 directory}"
: "${PREPARED_INPUT:?set PREPARED_INPUT to the exact separate Thor fixture}"
: "${CUTLASS_ROOT:?set CUTLASS_ROOT to the compatible full headers used for reproduction}"

git -c core.autocrlf=false clone https://github.com/Ther-nullptr/piR2.git "$ROOT"
git -C "$ROOT" -c core.autocrlf=false checkout 3c96deed507daa2878dc7e78b0deee9431ceec32
git -C "$ROOT" -c core.autocrlf=false apply --check "$PACKAGE/patches/progressive-main-3c96deed.patch"
git -C "$ROOT" -c core.autocrlf=false apply "$PACKAGE/patches/progressive-main-3c96deed.patch"
git -c core.autocrlf=false clone https://github.com/pi-r2-flow/Isaac-GR00T.git "$GROOT_SOURCE"
git -C "$GROOT_SOURCE" -c core.autocrlf=false checkout 2a39d591a3af24c42bb1d1c9cd708a2dddac0600
git -C "$GROOT_SOURCE" -c core.autocrlf=false apply --check "$PACKAGE/patches/groot-reproduction-fixes.patch"
git -C "$GROOT_SOURCE" -c core.autocrlf=false apply "$PACKAGE/patches/groot-reproduction-fixes.patch"
cp "$PACKAGE/patches/groot-reproduction-fixes.patch" "$GROOT_SOURCE/applied-maintainer.patch"
cp "$PACKAGE/manifests/GROOT_SOURCE_MANIFEST.json" "$GROOT_SOURCE/GROOT_SOURCE_MANIFEST.json"
mkdir -p "$ROOT/.local/scripts"
cp "$PACKAGE"/harness/* "$ROOT/.local/scripts/"
cp "$PACKAGE/manifests/source-manifest.json" "$ROOT/source-manifest.json"
cp "$PREPARED_INPUT" "$ROOT/.local/scripts/prepared-input.npz"

# Official CUDA 12.8 wheel channel; the general GR00T dependencies must already exist.
python -m pip install torch==2.10.0 torchvision==0.25.0 --index-url https://download.pytorch.org/whl/cu128
python -m pip install -r "$PACKAGE/requirements-observed.txt"
export CUDA_HOME="${CUDA_HOME:-/usr/local/cuda-12.8}"
export PATH="$CUDA_HOME/bin:$PATH"
export CUDA_VISIBLE_DEVICES=0 TORCH_CUDA_ARCH_LIST=8.9
export TORCH_EXTENSIONS_DIR="$ROOT/.local/torch210_extensions"
export TRITON_CACHE_DIR="$ROOT/.local/triton360"
export PYTHONPATH="$ROOT:$ROOT/scripts:$ROOT/.local/scripts:$GROOT_SOURCE"
export GROOT_HF_LOCAL_FIRST=1 GROOT_PATCH_MISTRAL=1 HF_HUB_OFFLINE=1
export NO_ALBUMENTATIONS_UPDATE=1 TOKENIZERS_PARALLELISM=false
export CUTLASS_ROOT GROOT_SOURCE
cd "$ROOT"
# Make offline nvidia/Cosmos-Reason2-2B config/tokenizer assets resolvable before loading.
# Hash-check the separate assets against manifests/input-provenance.json.
python -c 'from pathlib import Path; import os; from measurement_support import verify_source_manifest; verify_source_manifest(Path.cwd()); verify_source_manifest(Path(os.environ["GROOT_SOURCE"]), "GROOT_SOURCE_MANIFEST.json")'
python -m coexecution.kernels.build --backend integer --verbose
python -m coexecution.kernels.build --backend integer_dispatch --verbose
python -m coexecution.kernels.build --backend bf16_fusion --verbose
python tools/run_checks.py
python -m unittest discover -s .local/scripts -p test_measurement_support.py
PIR2_GPU_TESTS=1 python -m pytest -q tests/gpu/test_progressive_gpu.py
python .local/scripts/measure_progressive.py \
  --root "$ROOT" --checkpoint "$CHECKPOINT" \
  --prepared-input "$ROOT/.local/scripts/prepared-input.npz" \
  --thor-reference "$ROOT/.local/scripts/thor-reference.json" \
  --warmup 3 --repeats 10
# Results: results/measurements/summary.json and per-mode evidence.
