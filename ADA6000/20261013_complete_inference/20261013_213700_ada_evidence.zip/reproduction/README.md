# Ada full-inference 中间结果：复现源码

这是配套源码与执行说明，不是论文或新的实验结果。正式数据使用 piR2 `3c96deed` 加 `patches/progressive-main-3c96deed.patch`。补丁覆盖全部 9 个改动文件（含 3 个新增文件）；拥有的 CUDA/C++ 算子源码未改。上传源码归档的 263 个文件全部通过原 manifest 校验；补丁在独立目录应用后与实测 LF 字节一致。

本次口径：完整 CPU observation → `Backend.plan(visual=fresh_frame)` → 40×7 CPU action，每次 1 VLM + 1 streaming DiT。VLM 和非候选投影保持 BF16，仅 192 个 DiT Linear 候选按 11 档 W8A8→W4A4 转换。另测 original BF16、fusion+DiTGraph BF16，共 13 配置；warmup=3、repeat=10、seed=42，验证 seed=42/0/195。SDPA（main/text/vision）及 32 个 `AttnProcessor2_0`；固定配置顺序。bootstrap、状态/RNG恢复、编译、Graph capture在计时外；单次 profile另采。只作固定输入推理和数值诊断，不是闭环质量。

## 文件

- `patches/progressive-main-3c96deed.patch`：完整最小仓库差分。
- `harness/`：从实际上传归档提取的 LF 原件：measure/support/test、Thor reference和当时的notes。不得直接用本地CRLF文件替代。
- `manifests/source-manifest.json`：原实测源码清单；`GROOT_SOURCE_MANIFEST.json`：GR00T精确来源和维护者patch校验；`package-verification.json`：打包核查结果。
- `patches/groot-reproduction-fixes.patch`：维护者补丁原件；`manifests/input-provenance.json`：公开输入来源、fixture/逐数组/checkpoint摘要。
- `logs/`：正式 Torch 2.10 构建、335 Python/59 Node检查、4项新增GPU测试与测量日志，私有路径已替换。
- `audit/independent-audit.txt`、`.json`：仅对已保存的正式实测证据做CPU独立复核，1380项检查通过；没有新增GPU实测或闭环质量验证。

`harness/MEASUREMENT_NOTES.txt` 为保持 manifest 而保留原件，末尾“尚未GPU运行/3项local tests”是准备阶段旧状态；正式状态以 Torch 2.10 日志和配套结果为准。Torch 2.9 的 Conv3D fallback 诊断数据没有混入正式结果或此源码附件。

## 准备精确源码与输入

在 Linux/CUDA SM89 环境中，用独立checkout执行 `commands.sh` 中步骤。`PACKAGE` 指向本目录；`ROOT`、`GROOT_SOURCE` 分别指向新piR2和GR00T checkout。不要把旧外部 `robotics_kernels` 加到 `PYTHONPATH`。

GR00T来源是 `pi-r2-flow/Isaac-GR00T@2a39d591` 加所附维护者补丁；四个文件修改均有前后哈希。clone时关闭autocrlf，以保留LF。恢复harness到 `<ROOT>/.local/scripts/`，两份manifest分别放到对应源码根目录；harness会检查全部源文件。

输入来自公开数据集 [IPEC-COMMUNITY/libero_spatial_no_noops_1.0.0_lerobot](https://huggingface.co/datasets/IPEC-COMMUNITY/libero_spatial_no_noops_1.0.0_lerobot)，revision `bf14d6258218d12c2e3c1a3b9922e163cdf6455d`，episode 0/frame 20。Ada直接沿用Thor已解码CPU fixture以避免跨平台视频解码差异。fixture SHA256为 `9934a1a0f432f1e4408cbd47fa92b5187129d10b2efaa7cbe2fbc3c34e821116`；逐数组形状、类型和摘要见manifest。fixture、checkpoint和离线 `nvidia/Cosmos-Reason2-2B` 配置/tokenizer资产不随包提供，须另行获得。重解码公开数据不保证NPZ容器字节相同；源码manifest同时检查该NPZ文件摘要，不能随意重建后当作相同fixture。

## 依赖与执行

正式环境：Python 3.12.15；官方 Torch 2.10.0+cu128、torchvision 0.25.0+cu128；CUDA Toolkit 12.8；Triton 3.6.0。安装命令依据 [PyTorch官方历史版本页](https://pytorch.org/get-started/previous-versions/)。关键已观察包版本见 `requirements-observed.txt`；这不是完整环境锁文件。

原环境已准备GR00T常规依赖。GR00T原pyproject的Python/Torch约束与本次实测环境不同，不能直接依其默认依赖安装而覆盖 Torch 2.10。此处通过 `PYTHONPATH` 加载已核对源码，并在准备好的GR00T依赖环境中固定已记录的核心版本。没有声称已验证任意干净环境的一键重建。

CUTLASS使用了环境提供的完整headers，实际Git revision未知；记录的header fingerprint为 `6226274f7ee88c43b4c849a39e69dcf94d8c57ee7b0b95c1d8dd63dc6a65d543`，不匹配仓库推荐pin。`owned_dirty=false` 表示拥有的算子源码未变；整体 `dirty=true` 来自这项外部依赖差异。使用仓库默认CUTLASS可作为新的构建方案，但不能标记为本次依赖完全相同。

依次执行：源码/输入准备 → 官方Torch与核心依赖安装 → owned integer/dispatch/BF16 fusion构建 → 检查 → measure。具体命令见 `commands.sh`。原始测量harness不变；它对strict权重加载、VLM/DiT调用数、cuDNN卷积、Graph无计时内capture、完整动作有限性和scope恢复做断言。

本包不含模型权重、prepared NPZ、原始大trace、SSH地址、凭据或私有绝对路径。全部正式统计图表由父级结果附件提供，本目录只提供源码复现材料。
