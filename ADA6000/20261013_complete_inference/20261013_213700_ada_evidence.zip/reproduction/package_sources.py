"""Prepare a compact source-only reproduction attachment from a measured archive."""
import argparse
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import tempfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def write_json(path, data):
    save(path, (json.dumps(data, indent=2, ensure_ascii=False) + "\n").encode())


def sanitize(value):
    if isinstance(value, dict):
        return {k: sanitize(v) for k, v in value.items()}
    if isinstance(value, list):
        return [sanitize(v) for v in value]
    if not isinstance(value, str):
        return value
    value = re.sub(r"/home/[^/\s]+/piR2/\.local/streaming-spatial-20261010/outputs/libero-pir2-seed1000/libero-pir2-seed1000/checkpoint-500", "<CHECKPOINT_DIR>", value)
    value = re.sub(r"/home/[^/\s]+/pir2-ada-complete-20261013", "<EXPERIMENT_ROOT>", value)
    value = re.sub(r"/home/[^/\s]+/[^\s\"']+", "<EXTERNAL_DEPENDENCY_PATH>", value)
    value = re.sub(r"GPU-[0-9a-fA-F-]{36}", "<GPU_UUID_REDACTED>", value)
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.output.resolve()
    evidence = repo / ".local/evidence"
    source_raw = (evidence / "source-manifest.json").read_bytes()
    groot_raw = (evidence / "GROOT_SOURCE_MANIFEST.json").read_bytes()
    manifest = json.loads(source_raw)
    groot = json.loads(groot_raw)
    env = json.loads((evidence / "results/environment.json").read_bytes())
    summary = json.loads((evidence / "results/measurements/summary.json").read_bytes())
    base = manifest["base_revision"]
    assert base == "3c96deed507daa2878dc7e78b0deee9431ceec32"
    archive_path = repo / ".local/run-source.tar.gz"
    with tarfile.open(archive_path) as archive:
        contents = {name: archive.extractfile(name).read() for name in manifest["files"]}
    assert all(digest(content) == manifest["files"][name] for name, content in contents.items())
    assert digest(source_raw) == summary["identity"]["source_sha256"]
    assert digest(groot_raw) == summary["identity"]["model_source_manifest_sha256"]
    changed = [name for name in manifest["changed_files"] if not name.startswith(".local/")]
    assert len(changed) == 9
    patch_lines, before, new_files = [], {}, []
    for name in changed:
        original = subprocess.run(["git", "show", base + ":" + name], cwd=repo, capture_output=True)
        old = original.stdout if original.returncode == 0 else b""
        if original.returncode:
            new_files.append(name)
        before[name] = old
        actual = contents[name]
        assert b"\r" not in actual
        if name.endswith(".py"):
            ast.parse(actual.decode())
        patch_lines.append(f"diff --git a/{name} b/{name}\n")
        if original.returncode:
            patch_lines.append("new file mode 100644\n")
        patch_lines.extend(difflib.unified_diff(old.decode().splitlines(True), actual.decode().splitlines(True),
            fromfile="/dev/null" if original.returncode else "a/" + name, tofile="b/" + name))
    assert len(new_files) == 3
    patch_path = out / "patches/progressive-main-3c96deed.patch"
    save(patch_path, "".join(patch_lines).encode())
    with tempfile.TemporaryDirectory(prefix="verify-patch-", dir=out.parent) as temp:
        verify = Path(temp).resolve()
        assert verify.is_relative_to(out.parent)
        for name, old in before.items():
            if name not in new_files:
                save(verify / name, old)
        clean_env = dict(os.environ, GIT_CEILING_DIRECTORIES=str(out.parent))
        for extra in (["--check"], []):
            subprocess.run(["git", "-c", "core.autocrlf=false", "apply", *extra, str(patch_path)], cwd=verify, env=clean_env, check=True, capture_output=True)
        mismatches = [name for name in changed if (verify / name).read_bytes() != contents[name]]
        assert not mismatches, mismatches
    cuda_files = [name for name in contents if name.startswith("coexecution/kernels/") and Path(name).suffix in (".cu", ".cuh", ".cpp")]
    for name in cuda_files:
        assert subprocess.check_output(["git", "show", base + ":" + name], cwd=repo) == contents[name]
    assets = []
    for name in manifest["changed_files"]:
        if not name.startswith(".local/scripts/") or name.endswith(".npz"):
            continue
        relative = "harness/" + Path(name).name
        actual = contents[name]
        assert b"\r" not in actual
        save(out / relative, actual)
        assets.append({"path": relative, "restore_path_in_checkout": name, "sha256": digest(actual), "bytes": len(actual), "byte_identical_to_uploaded_run_archive": True})
    save(out / "manifests/source-manifest.json", source_raw)
    save(out / "manifests/GROOT_SOURCE_MANIFEST.json", groot_raw)
    maintained_patch = contents["patches/groot-reproduction-fixes.patch"]
    assert digest(maintained_patch) == groot["maintainer_patch_sha256"]
    save(out / "patches/groot-reproduction-fixes.patch", maintained_patch)
    save(out / "manifests/sources.lock.json", contents["sources.lock.json"])
    write_json(out / "manifests/environment-sanitized.json", sanitize(env))
    thor = json.loads(contents[".local/scripts/thor-reference.json"])
    write_json(out / "manifests/input-provenance.json", {
        "dataset": {"repository": "IPEC-COMMUNITY/libero_spatial_no_noops_1.0.0_lerobot",
            "url": "https://huggingface.co/datasets/IPEC-COMMUNITY/libero_spatial_no_noops_1.0.0_lerobot",
            "revision": "bf14d6258218d12c2e3c1a3b9922e163cdf6455d", "episode_index": 0, "frame_index": 20},
        "preparation": "Original Thor measurement harness used observations_and_prefixes(core, dataset, 0, 20, 1, torchcodec), then saved the decoded CPU arrays. Ada reused that exact prepared fixture; it did not decode the video again.",
        "fixture_bundled": False, "fixture_sha256": thor["prepared_input_sha256"],
        "array_hashes": thor["input_array_hashes"], "input_metadata": thor["input_metadata"],
        "checkpoint_sha256": thor["identity"]["checkpoint"]["sha256"], "thor_reference": thor["reference_source"],
        "restoration_requirement": "Place the separately obtained exact fixture at .local/scripts/prepared-input.npz; source-manifest checks the NPZ file bytes, while read_matched_input additionally checks each array. Independently re-decoding the public dataset is not claimed byte-identical.",
        "offline_model_config_assets": env["offline_assets"]})
    logs = []
    for path in sorted((evidence / "results/checks").glob("*torch210.log")):
        cleaned = sanitize(path.read_text(encoding="utf-8"))
        target = out / "logs" / path.name
        save(target, cleaned.encode())
        logs.append({"path": "logs/" + path.name, "original_sha256": digest(path.read_bytes()),
            "distributed_sha256": digest(target.read_bytes()), "sanitization": "Private absolute roots replaced with placeholders; measurements/test outcomes unchanged."})
    for path in sorted((evidence / "results/checks").glob("build210-*.log")):
        save(out / "logs" / path.name, path.read_bytes())
    audits = []
    for name in ("independent-audit.txt", "independent-audit.json"):
        original = evidence / "results" / name
        target = out / "audit" / name
        if original.suffix == ".json":
            write_json(target, sanitize(json.loads(original.read_bytes())))
        else:
            save(target, sanitize(original.read_text(encoding="utf-8")).encode())
        audits.append({"path": "audit/" + name, "original_sha256": digest(original.read_bytes()),
            "distributed_sha256": digest(target.read_bytes()),
            "scope": "CPU-only independent checks of saved formal measurements; no new GPU run.",
            "sanitization": "Private path/host identifiers replaced when present; numerical audit contents unchanged."})
    write_json(out / "manifests/package-verification.json", {
        "base_repository": manifest["base_url"], "base_revision": base,
        "measured_source_archive_sha256": digest(archive_path.read_bytes()),
        "source_manifest_sha256": digest(source_raw), "groot_manifest_sha256": digest(groot_raw),
        "all_archive_files_match_manifest": True, "archive_file_count_verified": len(contents),
        "runtime_patch": "patches/progressive-main-3c96deed.patch", "patch_sha256": digest(patch_path.read_bytes()),
        "changed_files": changed, "new_files_in_patch": new_files, "patch_application_verified": True,
        "applied_files_match_measured_lf_bytes": True, "owned_cuda_cpp_source_unchanged": True,
        "owned_cuda_cpp_files_verified": cuda_files, "harness": assets, "sanitized_logs": logs,
        "independent_saved_evidence_audit": audits,
        "reproduction_commands": {"path": "commands.sh", "sha256": digest((out / "commands.sh").read_bytes()),
            "gpu_test_opt_in": "PIR2_GPU_TESTS=1"},
        "official_torch_install_source": "https://pytorch.org/get-started/previous-versions/",
        "excluded": ["prepared-input.npz", "model weights", "raw profiler traces", "SSH addresses/credentials", "private absolute paths", "Torch 2.9 diagnostic measurements"],
        "formal_runtime": summary["identity"]["runtime"], "formal_package_versions": summary["identity"]["package_versions"],
        "limitations": ["CUTLASS actual Git revision is unknown; selected header fingerprint differs from recommended pin and is retained in environment-sanitized.json.",
            "The observed environment was prepared in advance; this attachment does not claim a clean-install end-to-end reproduction without the separately supplied input fixture, checkpoint and offline assets.",
            "Original MEASUREMENT_NOTES.txt is preserved byte-for-byte for the manifest; its local-preparation status paragraph predates the final run. Formal status comes from the Torch 2.10 logs and exported results."]})
    print(json.dumps({"staging": str(out), "patch_files": len(changed), "new_files": len(new_files),
        "archive_files_verified": len(contents), "owned_cuda_cpp_files_verified": len(cuda_files),
        "harness_files": len(assets)}, indent=2))


if __name__ == "__main__":
    main()
