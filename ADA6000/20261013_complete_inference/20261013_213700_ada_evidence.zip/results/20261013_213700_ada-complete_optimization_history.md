# Ada full-call progressive quantization

Generated: 2026-10-13T21:37:00+08:00

Evidence: **measured**. [Overview](20261013_213700_ada-complete_optimization_history_p03.png).

![History page 1](20261013_213700_ada-complete_optimization_history_p01.png)

![History page 2](20261013_213700_ada-complete_optimization_history_p02.png)

![History page 3](20261013_213700_ada-complete_optimization_history_p03.png)

| Run | Protocol / cohort | Configuration | Time | n | Adoption | Quality |
|---|---|---|---:|---:|---|---|
| original_bf16 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Original BF16 | 52.3637 ms | 10 | experimental | unmeasured |
| bf16 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Shared BF16 | 46.5172 ms | 10 | experimental | unmeasured |
| tier00 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | W8A8 | 47.8763 ms | 10 | experimental | unmeasured |
| tier01 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Tier 1 | 47.6965 ms | 10 | experimental | unmeasured |
| tier02 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Tier 2 | 47.722 ms | 10 | experimental | unmeasured |
| tier03 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Tier 3 | 47.4335 ms | 10 | experimental | unmeasured |
| tier04 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Tier 4 | 47.4155 ms | 10 | experimental | unmeasured |
| tier05 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Tier 5 | 47.9071 ms | 10 | experimental | unmeasured |
| tier06 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Tier 6 | 49.7847 ms | 10 | experimental | unmeasured |
| tier07 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Tier 7 | 46.2911 ms | 10 | experimental | unmeasured |
| tier08 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Tier 8 | 46.6208 ms | 10 | experimental | unmeasured |
| tier09 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | Tier 9 | 46.2552 ms | 10 | experimental | unmeasured |
| tier10 | fresh-plan / 4504e11effbaee41ce9eac35dc2456dacae7a3b9a36339a3426f9141c9896d43 | W4A4 | 46.0787 ms | 10 | experimental | unmeasured |

## Explicit Comparisons

| Kind | Baseline | Candidate | Speedup | Saved (protocol unit) |
|---|---|---|---:|---:|
| cumulative | original_bf16 | bf16 | 1.12569x | +5.84653 |
| cumulative | original_bf16 | tier00 | 1.09373x | +4.48747 |
| incremental | bf16 | tier00 | 0.971613x | -1.35906 |
| cumulative | original_bf16 | tier01 | 1.09785x | +4.66725 |
| incremental | bf16 | tier01 | 0.975275x | -1.17928 |
| cumulative | original_bf16 | tier02 | 1.09727x | +4.64177 |
| incremental | bf16 | tier02 | 0.974755x | -1.20475 |
| cumulative | original_bf16 | tier03 | 1.10394x | +4.93023 |
| incremental | bf16 | tier03 | 0.980683x | -0.916292 |
| cumulative | original_bf16 | tier04 | 1.10436x | +4.94827 |
| incremental | bf16 | tier04 | 0.981056x | -0.898256 |
| cumulative | original_bf16 | tier05 | 1.09303x | +4.45666 |
| incremental | bf16 | tier05 | 0.970988x | -1.38986 |
| cumulative | original_bf16 | tier06 | 1.0518x | +2.57907 |
| incremental | bf16 | tier06 | 0.934368x | -3.26745 |
| cumulative | original_bf16 | tier07 | 1.13118x | +6.07263 |
| incremental | bf16 | tier07 | 1.00488x | +0.226105 |
| cumulative | original_bf16 | tier08 | 1.12319x | +5.74299 |
| incremental | bf16 | tier08 | 0.997779x | -0.103535 |
| cumulative | original_bf16 | tier09 | 1.13206x | +6.10857 |
| incremental | bf16 | tier09 | 1.00567x | +0.262042 |
| cumulative | original_bf16 | tier10 | 1.1364x | +6.28509 |
| incremental | bf16 | tier10 | 1.00952x | +0.43856 |

Missing comparison edges are pending, not zero improvement. Ratios are never multiplied across rounds.
Numerical classifications are relative to the parent; adoption and quality are separate fields.

## Notes

- Current run is the explicit full-coverage endpoint, not a selected fastest configuration.
- Comparisons are directly measured within one cohort; coupled changes are attributed to their bundle.
- VLM and noncandidate precision remain BF16. Closed-loop quality is not measured.
- Ada INT8/INT4 and Thor FP8/FP4 are different formats; their curves are not a pure hardware comparison.

## Sources

- 20261013_213700_ada_measurement_summary.json
