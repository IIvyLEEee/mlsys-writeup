# Ada progressive integer quantization

Generated: 2026-10-13T21:37:00+08:00

Metric: GPU operation duration sum (ms); One warmed call; kernels + transfers; excludes CPU gaps.

![Measured breakdown](20261013_213700_ada-complete-gpu_profile_breakdown.svg)

| Component | Original BF16 | Shared BF16 | W8A8 | W4A4 |
|---|---:|---:|---:|---:|
| GEMM / GEMV | 17.0251 | 16.9435 | 17.46 | 15.7613 |
| GEMM reductions / epilogues | 0.877671 | 0.845927 | 0.378176 | 0.379681 |
| Attention | 2.16888 | 2.11942 | 2.10956 | 2.10668 |
| Softmax | 0 | 0 | 0 | 0 |
| Normalization / reductions | 1.80419 | 1.78735 | 1.406 | 1.40655 |
| Fused producer | 0 | 0 | 0.592234 | 0.489068 |
| Activation preparation / packing | 0 | 0 | 0.587591 | 0.578891 |
| Layout / copy / cast | 2.53977 | 0.472003 | 0.706122 | 0.705612 |
| Convolution | 0.068224 | 0.068449 | 0.068128 | 0.068353 |
| Pointwise fusion | 0 | 0.372099 | 0.302305 | 0.302338 |
| GELU / activation | 0.50407 | 0.36957 | 0.284354 | 0.284806 |
| Indexing / gather / scatter | 0.253924 | 0.25437 | 0.254083 | 0.25437 |
| Elementwise other | 3.84888 | 0.888931 | 0.826957 | 0.827909 |
| Unknown kernel | 0.181374 | 0.182943 | 0.181343 | 0.182562 |
| GPU transfers / memset | 0.354246 | 0.402147 | 0.382118 | 0.352546 |
| Total | 29.6264 | 24.7067 | 25.539 | 23.7006 |


## Notes

- GPU durations can overlap; this is not a decomposition of clean wall latency.
- Activation preparation may include fused activation; fused producers are not split into estimates.
- Unknown kernel work is retained. Task quality and closed-loop success are unmeasured.

## Sources

- 20261013_213700_ada_measurement_summary.json
